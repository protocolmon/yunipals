import BN from 'bn.js';
import { ChainId, OwnerInfo } from '.';
export type Data = Record<string, string | number | Date | undefined | unknown>;
export interface Attribute extends Data {
    type?: string;
    value: string | number;
}
export type Attributes<T extends string = string> = Record<T, Attribute>;
type FieldValues = string | number | Date | Data | Attributes<string> | unknown;
export type Instance = Record<string, FieldValues>;
export type BigNumber = BN;
export type ID = string | number | BigNumber;
export declare const NULL_ID: ID;
export declare const BURN_ID: string;
export declare const toAddress: (id: ID) => ID;
export interface TokenOwnerResolver {
    getTokenOwnerById: (chainId: ChainId, id: ID) => Promise<OwnerInfo | undefined>;
    getTokensOwnerById: (chainId: ChainId, ids: ID[]) => Promise<[ID, OwnerInfo | undefined][]>;
}
export {};
