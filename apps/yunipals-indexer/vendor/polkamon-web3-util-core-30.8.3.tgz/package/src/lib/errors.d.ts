export declare class SignatureValidationError extends Error {
}
