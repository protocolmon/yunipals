import { Instance } from '../common-types';
declare const GENERATION_TYPE: readonly ["GEN1", "ISLAND", "AI1", "AI2", "AI_ADV1", ...("POLYGEAR_ORIGIN_S001E001" | "GEN1_XMAS22_S001E001" | "GEN1_ORIGIN_S001E001" | "GEN1_ORIGIN_S001E002")[]];
export type GENERATION_TYPE = (typeof GENERATION_TYPE)[number];
export declare const GenerationType: ReadonlyArray<GENERATION_TYPE>;
export interface GenerationId extends Instance {
    id: string;
    type: GENERATION_TYPE;
}
export declare const toGenId: (type: GENERATION_TYPE, id: string) => GenerationId;
export declare const genToId: ({ id, type }: GenerationId) => string;
export declare const toGenIds: (ids: string[], type: GENERATION_TYPE) => string[];
export declare const toGen1Ids: (ids: string[]) => string[];
export declare const toGen1Id: (id: string) => string;
export {};
