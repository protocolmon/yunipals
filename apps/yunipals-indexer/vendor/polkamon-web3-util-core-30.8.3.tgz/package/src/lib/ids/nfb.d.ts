import { GenerationId } from './base';
export interface NFBSourceInfo {
    series: string | number;
    edition: string | number;
    prefix: NFBOrigins;
}
declare const NFB_ORIGINS: readonly ["GEN1_XMAS22", "GEN1_ORIGIN", "POLYGEAR_ORIGIN"];
export type NFBOrigins = (typeof NFB_ORIGINS)[number];
export declare const NFBOrigins: ReadonlyArray<NFBOrigins>;
declare const POLYGEAR_NFTBS: readonly ["POLYGEAR_ORIGIN_S001E001"];
export type PolygearNfbs = (typeof POLYGEAR_NFTBS)[number];
export declare const PolygearNfbs: ReadonlyArray<PolygearNfbs>;
declare const GEN1_NFTBS: readonly ["GEN1_XMAS22_S001E001", "GEN1_ORIGIN_S001E001", "GEN1_ORIGIN_S001E002"];
export type Gen1Nfbs = (typeof GEN1_NFTBS)[number];
export declare const Gen1Nfbs: ReadonlyArray<Gen1Nfbs>;
declare const NFTBS: readonly ["GEN1_XMAS22_S001E001", "GEN1_ORIGIN_S001E001", "GEN1_ORIGIN_S001E002", "POLYGEAR_ORIGIN_S001E001"];
export type Nfbs = (typeof NFTBS)[number];
export declare const Nfbs: ReadonlyArray<Nfbs>;
declare const NFT_FROM_NFB_ORIGINS: readonly ["GEN1_XMAS22_S001E001", "GEN1_ORIGIN_S001E001", "GEN1_ORIGIN_S001E002", "POLYGEAR_ORIGIN_S001E001"];
export type NftFromNfbOrigins = (typeof NFT_FROM_NFB_ORIGINS)[number];
export declare const NftFromNfbOrigins: ReadonlyArray<NftFromNfbOrigins>;
export declare const generateNFBCode: ({ series, edition }: Omit<NFBSourceInfo, 'prefix'>) => string;
export declare const generateNFBGenId: (chainId: string, nfbId: string, info: NFBSourceInfo) => GenerationId;
export declare const generateNFBGenType: ({ prefix, ...rest }: NFBSourceInfo) => Nfbs;
export declare const getTokeIdFromNFBGenId: ({ type, id }: GenerationId) => string;
export {};
