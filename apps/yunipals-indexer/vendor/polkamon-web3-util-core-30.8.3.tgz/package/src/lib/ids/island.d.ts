import { ChainGroup } from '../chain';
declare const ISLAND_ORIGINS: readonly ["ETHEREUM_ISLAND", "POLYGON_ISLAND", "BSC_ISLAND"];
export type IslandOrigins = (typeof ISLAND_ORIGINS)[number];
export declare const IslandOrigins: ReadonlyArray<IslandOrigins>;
export declare const toIslandGenId: (chainGroup: ChainGroup, id: string) => import("./base").GenerationId;
export {};
