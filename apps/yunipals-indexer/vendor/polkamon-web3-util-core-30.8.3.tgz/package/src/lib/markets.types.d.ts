export interface Trait extends Record<string, string | number | undefined> {
    display_type?: string;
    trait_type: string;
    value: string | number;
}
