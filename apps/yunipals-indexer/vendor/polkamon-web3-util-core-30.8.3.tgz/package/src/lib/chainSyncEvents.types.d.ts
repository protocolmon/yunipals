import { BigNumber } from '@ethersproject/bignumber';
export interface ChainEvent<T = unknown> {
    id: string;
    blockNumber: number;
    blockTimeStamp: number;
    type: string;
    identifier: string;
    transactionHash: string;
    event?: string;
    args: T;
    createdAt?: Date;
    updatedAt?: Date;
    address?: string;
}
export type TransferEvent = ChainEvent<{
    0: string;
    1: string;
    2: string;
}>;
export type BurnEvent = ChainEvent<{
    0: string;
    1: string;
}>;
export type ReverseSwapBurnEvent = BurnEvent;
export type UtilityTrackerBurnEvent = BurnEvent;
export type RainbowFusionEvent = ChainEvent<{
    0: string;
    1: string;
    2: string;
    3: string;
    4: BigNumber[];
}>;
export type GhostHatchEvent = ChainEvent<{
    0: string;
    1: string;
    2: string;
}>;
export type RandomnessFulfilledEvent = ChainEvent<{
    0: string;
    1: string;
    2: string;
}>;
export type CrystalEggHatchEvent = ChainEvent<{
    0: string;
    1: string;
    2: string;
}>;
declare enum PositionUpdateType {
    STAKE = 0,
    UNSTAKE = 1,
    WITHDRAW = 2,
    LEVELUP = 3,
    MOVE_TO_LIMITED_POOL = 4
}
export type PolyboostMassPositionUpdateEvent = ChainEvent<{
    0: PositionUpdateType;
    1: string;
    2: BigNumber[];
}>;
export {};
