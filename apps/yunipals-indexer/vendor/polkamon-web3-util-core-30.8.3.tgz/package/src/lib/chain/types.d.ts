declare const CHAIN_TYPES: readonly ["EVM", "SOLANA", "NEO"];
export declare const ChainTypes: ReadonlyArray<ChainType>;
export type ChainType = (typeof CHAIN_TYPES)[number];
declare const CHAIN_CURRENCYS: readonly ("SOL" | "ETH" | "BNB" | "MATIC" | "GAS")[];
export declare const ChainCurrencies: ReadonlyArray<ChainCurrency>;
export type ChainCurrency = (typeof CHAIN_CURRENCYS)[number];
declare const CHAIN_GROUPS: readonly ("SOLANA" | "ETHEREUM" | "BSC" | "POLYGON" | "ARBITRUM" | "ARBITRUM_NOVA" | "OPTIMISM" | "BASE" | "NEO")[];
export declare const ChainGroups: ReadonlyArray<ChainGroup>;
export type ChainGroup = (typeof CHAIN_GROUPS)[number];
export declare const CHAIN_ENV_MAINNET = "MAINNET";
export declare const CHAIN_ENV_TESTNET = "TESTNET";
export type CHAIN_ENV = 'MAINNET' | 'TESTNET';
declare const CHAIN_IDS: readonly ("mainnet-beta" | "devnet" | "testnet" | "1" | "4" | "5" | "10" | "56" | "97" | "137" | "8453" | "42161" | "42170" | "80001" | "neo3:mainnet" | "neo3:testnet" | "neo3:private")[];
export type ChainId = (typeof CHAIN_IDS)[number];
export declare const ChainIds: ReadonlyArray<ChainId>;
export type ChainIdInput = ChainId | number | string;
export interface Chain<I extends ChainId = ChainId, G extends ChainGroup = ChainGroup, T extends ChainType = ChainType, C extends ChainCurrency = ChainCurrency> {
    readonly id: I;
    readonly label: string;
    readonly group: G;
    readonly type: T;
    readonly currency: C;
    readonly defaultRpcUrl: string;
    readonly defaultBlockExplorerUrl: string;
    readonly isTestnet: boolean;
}
export type SlimChain = Readonly<Pick<Chain, 'id' | 'type'>>;
export {};
