import { Chain, ChainGroup, ChainIdInput } from './types';
export declare const getChains: (isTestnet?: boolean) => Chain[];
export declare const getChainById: (chainId: ChainIdInput) => Chain | undefined;
export declare const getChainByGroup: (chainGroup: ChainGroup, isTestnet?: boolean) => Chain | undefined;
export declare const isChainId: (chainId: ChainIdInput) => boolean;
