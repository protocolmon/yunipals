import { SolanaChain } from './types';
export declare const SOLANA_MAINNET: Readonly<SolanaChain>;
export declare const SOLANA_DEVNET: Readonly<SolanaChain>;
export declare const SOLANA_CHAINS: Readonly<SolanaChain[]>;
export declare const getSolanaChain: (isTestnet?: boolean) => SolanaChain | undefined;
