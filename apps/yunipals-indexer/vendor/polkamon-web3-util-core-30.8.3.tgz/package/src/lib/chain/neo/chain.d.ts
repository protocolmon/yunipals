import { NeoChain } from './types';
export declare const NEO_MAINNET: Readonly<NeoChain>;
export declare const NEO_TESTNET: Readonly<NeoChain>;
export declare const NEO_CHAINS: Readonly<NeoChain[]>;
export declare const getNeoChain: (isTestnet?: boolean) => NeoChain | undefined;
