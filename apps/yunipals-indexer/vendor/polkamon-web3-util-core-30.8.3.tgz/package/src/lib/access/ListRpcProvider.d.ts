import { ContractInterface, Contract } from '@ethersproject/contracts';
import { ChainId } from '../chain';
import { ContractProvider, RpcProvider } from './types';
import { JsonRpcOptions } from './utils';
export interface ListRpcProviderCreateArgs {
    rpcUrls: string[];
    chainId: ChainId;
    providerOptions?: JsonRpcOptions;
}
export declare class ListRpcProvider implements ContractProvider {
    private nextIndex;
    private current;
    private providers;
    private urls;
    constructor(config: Record<string, RpcProvider>);
    getContract: (address: string, abi: ContractInterface) => Promise<Contract>;
    getProvider: () => Promise<RpcProvider>;
    useNext: () => string;
    static create: ({ rpcUrls, chainId, providerOptions }: ListRpcProviderCreateArgs) => ListRpcProvider;
}
