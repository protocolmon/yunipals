import { Contract } from '@ethersproject/contracts';
import { ListRpcProvider } from '../ListRpcProvider';
import { RpcProviderApi, RpcCall, RpcCallOptions, RpcContractApi, RpcContractCall } from '../types';
import { FallbackRpcApiConfig, FallbackRpcContractApiConfig, FallbackRpcContractCreateArgs, FallbackRpcCreateArgs } from './types';
declare abstract class AbstractRpcApi<T extends FallbackRpcApiConfig = FallbackRpcApiConfig> implements RpcProviderApi {
    protected listProvier: ListRpcProvider;
    protected config: T;
    constructor(listProvier: ListRpcProvider, config?: T);
    request: <T_1>(call: RpcCall<T_1>, options?: Partial<RpcCallOptions>) => Promise<T_1>;
    protected doWithRetry: <T_1>(call: () => Promise<T_1>, { logPrefix: loggerPrefix, ...options }?: Partial<RpcCallOptions>) => Promise<T_1>;
    protected log: (message: string, error?: Error | string, verbose?: boolean) => void;
}
export declare class FallbackRpcApi extends AbstractRpcApi implements RpcProviderApi {
    static create: (config: FallbackRpcCreateArgs) => FallbackRpcApi;
}
export declare class FallbackRpcContractApi extends AbstractRpcApi<FallbackRpcContractApiConfig> implements RpcContractApi {
    getContract: () => Promise<Contract>;
    callContract: <T>(call: RpcContractCall<T>, options?: Partial<RpcCallOptions>) => Promise<T>;
    private getContractWith;
    static create: (config: FallbackRpcContractCreateArgs) => FallbackRpcContractApi;
}
export {};
