import { JsonRpcProvider, Provider } from '@ethersproject/providers';
import { ChainId } from '../chain';
import { Contract, ContractInterface } from '@ethersproject/contracts';
import { ConnectionInfo } from '@ethersproject/web';
import { RPCProviderConfig } from './types';
export type JsonRpcOptions = Omit<ConnectionInfo, 'url'>;
export declare const getJsonRpcProvider: (url: string, chainId?: ChainId, options?: JsonRpcOptions) => JsonRpcProvider;
export declare const getContract: (provider: Provider, address: string, abi: ContractInterface) => Promise<Contract>;
export declare const resolveRpcs: () => RPCProviderConfig;
