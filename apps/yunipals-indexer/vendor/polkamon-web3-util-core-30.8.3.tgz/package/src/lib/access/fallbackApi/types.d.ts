import { Logger } from '@polkamon/util-essentials';
import { ListRpcProviderCreateArgs } from '../ListRpcProvider';
import { Abi } from '../types';
import { WrapOptions } from 'retry';
export interface FallbackRpcApiConfig {
    logger?: Logger;
    retriesPerRpc?: number;
    verbose?: boolean;
    retries?: WrapOptions;
}
export type FallbackRpcCreateArgs = ListRpcProviderCreateArgs & FallbackRpcApiConfig;
export interface FallbackRpcContractApiConfig extends FallbackRpcApiConfig {
    address: string;
    abi: Abi;
}
export type FallbackRpcContractCreateArgs = ListRpcProviderCreateArgs & FallbackRpcContractApiConfig;
