import { Contract as ETHContract, ContractInterface } from '@ethersproject/contracts';
import { Provider } from '@ethersproject/providers';
import { ChainGroup } from '../chain';
export type Contract = ETHContract;
export type Abi = ContractInterface;
export type Address = string;
export type RpcProvider = Provider;
export interface ContractProvider {
    getProvider(): Promise<RpcProvider>;
    getContract(address: Address, abi: Abi): Promise<Contract>;
}
export interface RpcCallArgs {
    provider: RpcProvider;
}
export type RpcCall<T> = (args: RpcCallArgs) => Promise<T>;
export interface RpcContractCallArgs extends RpcCallArgs {
    contract: Contract;
}
export type RpcContractCall<T> = (args: RpcContractCallArgs) => Promise<T>;
export interface RpcCallOptions {
    logPrefix: string;
    randomize: boolean;
    retries: number;
    maxTimeout: number;
}
export interface RpcProviderApi {
    request<T>(call: RpcCall<T>, options?: Partial<RpcCallOptions>): Promise<T>;
}
export interface RpcContractApi {
    callContract<T>(call: RpcContractCall<T>, options?: Partial<RpcCallOptions>): Promise<T>;
    getContract(): Promise<Contract>;
}
export type RpcApi = RpcProviderApi & RpcContractApi;
export type RPCProviderConfig = Partial<Record<ChainGroup, string[]>>;
export type RPCConfig = {
    provider: RPCProviderConfig;
    callOptions: Partial<RpcCallOptions>;
};
