import { ChainId } from './chain';
declare const COLLECTION_UPDATE_TRIGGER_TYPES: readonly ["burned", "transferred"];
export declare const CollectionUpdateTriggerTypes: ReadonlyArray<CollectionUpdateTriggerType>;
export type CollectionUpdateTriggerType = (typeof COLLECTION_UPDATE_TRIGGER_TYPES)[number];
declare const COLLECTION_UPDATE_TRIGGERS: readonly ["EXOMON_UNSTAKE", "EXOMON_STAKE", "REVERSE_SWAP", "RAINBOW_FUSION", "EGG_HATCHING", "CLAIM_PMON_FROM_EXPERIMENTAL", "CLAIM_PMON_FROM_EXPERIMENTAL_V2", "NFB_TRANSFER", "GHOSTPORTAL_FUSION", "EXPERIMENTAL_PACK_V2_TRANSFER"];
export declare const CollectionUpdateTriggers: ReadonlyArray<CollectionUpdateTrigger>;
export type CollectionUpdateTrigger = (typeof COLLECTION_UPDATE_TRIGGERS)[number];
export interface CollectionUpdateDataInterface {
    trigger: CollectionUpdateTrigger;
    chainId: ChainId;
    transactionHash: string;
    walletAddress: string;
}
export interface TransferDataInterface {
    from: string;
    to: string;
    tokenId: string;
}
export interface BurnUpdateData extends CollectionUpdateDataInterface {
    burnedTokenIds: string[];
}
export interface TransferUpdateData extends CollectionUpdateDataInterface {
    transfer: TransferDataInterface;
}
export interface OptimisticChangeInterface {
    triggerType: CollectionUpdateTriggerType;
    changedAt?: Date;
    updateData?: BurnUpdateData | TransferUpdateData | Record<string, unknown>;
}
export {};
