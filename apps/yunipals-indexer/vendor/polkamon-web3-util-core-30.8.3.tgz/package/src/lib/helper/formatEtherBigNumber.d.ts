import { BigNumber } from '@ethersproject/bignumber';
/**
 * This function converts a Bignumber into a string representation with the desired amount of decimals
 * The number is then displayed in american style e.g. 1,000,000.1234
 */
export declare function formatEtherBigNumber(number: BigNumber, decimalCount?: number, unit?: number): string;
/**
 * converts a given BigNumber to a floating number with a fixed amount of fraction digits
 */
export declare function bigNumberToDecimal(number: BigNumber, decimalCount: number): number;
