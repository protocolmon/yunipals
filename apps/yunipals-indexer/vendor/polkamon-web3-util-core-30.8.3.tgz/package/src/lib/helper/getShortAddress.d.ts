export declare const getShortAddress: (address: string) => string;
