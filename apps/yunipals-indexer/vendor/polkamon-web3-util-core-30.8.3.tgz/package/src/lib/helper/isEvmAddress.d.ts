export declare const isEvmAddress: (address: string) => boolean;
