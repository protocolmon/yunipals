import { SlimChain } from './chain';
import { OptimisticChangeInterface } from './collectionChanges.types';
import { Attributes, Instance } from './common-types';
import { GenerationId, Origin } from './ids';
export interface Assets {
    imageUrl: string;
    imageAnimatedUrl?: string;
    videoUrl: string;
    pfpUrl?: string;
}
export type GatewayAssets = Assets;
export interface IPFSAssets extends Assets {
    code?: string;
    imageIpfsUrl?: string;
    imageAnimatedIpfsUrl?: string;
    videoIpfsUrl: string;
    pfpIpfsUrl?: string;
}
export type DelegationType = 'ON_ADVENTURE' | 'RAINBOW_PORTAL_STAKING' | 'ISLAND_STAKING';
export interface OwnerInfo {
    ownerAddress: string;
    ownerSince?: Date;
    delegateeAddress?: string;
    delegateeSince?: Date;
    delegationType?: DelegationType;
    transactionHash?: string;
}
export interface GiftData {
    sender: string;
    message?: string;
}
export interface NFTBaseEnvelope<T extends NFT = NFT, O extends Origin = Origin> extends OwnerInfo {
    id: string;
    genId: GenerationId;
    origin: O;
    chainOrigin: SlimChain;
    nft: T;
    createdAt: Date;
    updatedAt: Date;
    optimisticChange?: OptimisticChangeInterface;
    minted: boolean;
    burned?: boolean;
    chain: SlimChain;
    bridged?: boolean;
    giftData?: GiftData;
}
export interface NFTEnvelope<T extends NFT = NFT, O extends Origin = Origin> extends NFTBaseEnvelope<T, O> {
    rarity: number;
    rarityCapped: number;
    softMintHash?: string;
}
export interface NFT<T extends string = string, R extends string = string> extends Instance, IPFSAssets {
    id: string;
    type: R;
    chainOrigin: SlimChain;
    birthday: Date;
    hash: string;
    attributes: Attributes<T>;
    name?: string;
    description: string;
}
