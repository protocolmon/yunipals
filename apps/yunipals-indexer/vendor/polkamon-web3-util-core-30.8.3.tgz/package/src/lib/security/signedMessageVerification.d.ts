import { SignatureVerifierInterface, VerificationRequest } from './types';
export declare class SignatureVerifier implements SignatureVerifierInterface {
    private readonly skipVerification;
    constructor(skipVerification?: boolean);
    verifyEvmMessage({ message, signature, key: address }: VerificationRequest): boolean;
    verifySolanaMessage({ message, signature, key: publicKey }: VerificationRequest): boolean;
    verifySolanaTransaction({ message, signature: transactionSignature, key: publicKey }: VerificationRequest): boolean;
}
