export interface SignatureVerifierInterface {
    verifyEvmMessage(verifyRequest: VerificationRequest): boolean;
    verifySolanaMessage(verifyRequest: VerificationRequest): boolean;
    verifySolanaTransaction(verifyRequest: VerificationRequest): boolean;
}
export interface VerificationRequest {
    message: string;
    signature: string;
    key: string;
}
