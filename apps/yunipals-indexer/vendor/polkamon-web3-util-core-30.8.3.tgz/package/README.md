# web3-util-core

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test web3-util-core` to execute the unit tests via [Jest](https://jestjs.io).
