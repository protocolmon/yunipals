export declare const removeEmptyValues: (obj: unknown) => unknown;
export declare const uniqueArray: <T>(value: T, index: unknown, hostArray: T[]) => boolean;
export declare const cartesian: (...a: any[]) => any;
export declare const crossproduct: (xss: any) => any;
export declare const combinations: <R = Record<string | number, unknown>>(o: any, keys?: string[], vals?: unknown[]) => R[];
export declare const explode: <T>(o: {
    [s: string]: T;
}, builder?: ([key, value]: [any, any]) => unknown) => any[];
export declare const explodePropsToKeys: <T>(o: {
    [s: string]: T;
}) => any[];
export declare const explodePropsToValue: <T>(o: {
    [s: string]: T;
}) => any[];
type CellData = number | NumberCollection;
interface NumberCollection extends Record<never, CellData> {
}
export declare const mergeAdd: <T extends NumberCollection = NumberCollection>(a: T, b: T) => T;
export declare const sumAll: (a: NumberCollection) => number;
export declare const mergeSum: (a: NumberCollection, b: NumberCollection) => number;
export declare const mergeWithArray: <TObject, TSource>(objValue: TObject, srcValue: TSource) => TObject & TSource;
export declare const filterObject: <T>(src: T, projection: unknown) => Partial<T>;
export declare const unsetMany: <T>(src: T, toRemove: string[]) => Partial<T>;
export {};
