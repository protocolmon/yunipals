export type logFn = (message: string, data?: object) => void;
export interface Logger {
    trace: logFn;
    info: logFn;
    warn: logFn;
    error: logFn;
    debug: logFn;
    fatal: logFn;
}
export interface ExtendedLogger extends Logger {
    log: (level: string, message: string, data?: object) => void;
    format: (level: string, message: string, data?: object) => void;
}
