import { AxiosInstance, CreateAxiosDefaults } from 'axios';
import { CacheOptions } from 'axios-cache-interceptor';
import { IAxiosRetryConfig } from 'axios-retry';
export type HttpConfig = CreateAxiosDefaults & {
    retryOptions: IAxiosRetryConfig;
    cacheOptions: CacheOptions;
};
export declare function getHttpClient(input: Partial<HttpConfig>): AxiosInstance;
