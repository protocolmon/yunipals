export declare const noInfinity: (value: number, log?: (() => void) | string, defaultValue?: number) => number;
export declare const toInt: (value: string | undefined, defaultValue: number) => number;
export declare const toFloat: (value: string | undefined, defaultValue: number) => number;
export declare const toNumber: (value: string | undefined, defaultValue: number, parser: (value: string) => number) => number;
export declare const toHex: (number: unknown) => string;
export declare const toIntFromHex: (hexString: string) => number;
export declare const getPercent: (count: number, part: number) => number;
export declare const getPercentAsString: (count: number, part: number, decimals?: number) => string;
export declare const getPartOf: (total: number, part: number) => number;
export declare const getPartIn: (part: number, of: number, other: number) => number;
/**
 * Round like Google Sheets Round method. It always rounds based on the first digit after the requested digit amount.
 *
 * e.g. 1.2345 with 2 decimals will be rounded to 1.23
 * and 1.2355 with 2 decimals will be rounded to 1.24
 *
 * see
 */
export declare const roundLikeGoogleSheets: (input: number, decimals?: number) => number;
