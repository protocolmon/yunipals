import { PropertyName, PropertyPath } from 'lodash';
export declare const isNotUndefined: (value: any) => boolean;
export declare const isNotNil: (value: any) => boolean;
export declare const isNotEmpty: (value?: any) => boolean;
export declare const hasAll: <T>(obj: T, keys: PropertyPath[]) => boolean;
export declare const asMessage: (input: unknown) => string;
export declare const hasAny: (obj: object | null | undefined, prop: PropertyName) => boolean;
export declare const hasNone: (obj: object, prop: PropertyName) => boolean;
