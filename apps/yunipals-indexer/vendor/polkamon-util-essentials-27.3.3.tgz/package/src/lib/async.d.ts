import { Logger } from './logger';
export declare const delay: (ms: number) => Promise<unknown>;
export declare const defaultDelay: () => Promise<unknown>;
export interface ProcessControl {
    requestStop: () => Promise<boolean>;
    start: () => Promise<Job[]>;
}
export interface ProcessConfig {
    jobId: string;
    jobRunDelay: number;
    initialDelay?: number;
    initialDelayIfFinished?: number;
    logger?: Logger;
    startHook?: (jobConfig: ProcessConfig) => void;
    beforeRun?: (jobConfig: ProcessConfig) => void;
    afterRun?: (jobConfig: ProcessConfig) => void;
    endHook?: (jobConfig: ProcessConfig) => void;
    stopRequested?: () => boolean;
    stoppedHook?: (jobConfig: ProcessConfig) => void;
    errorHook?: (jobConfig: ProcessConfig) => void;
}
export declare const DefaultProcessConfig: (base?: Partial<ProcessConfig>) => ProcessConfig;
export type Job = {
    jobId: string;
    run: () => Promise<Partial<ProcessConfig> | undefined | void>;
};
export declare const startRecurringJob: (job: Job, inputConfig: Partial<ProcessConfig>) => any;
export declare const prepareRecurringJobs: (jobs: Job[], config: Partial<ProcessConfig>) => ProcessControl;
export declare class Deferred<T = unknown> {
    promise: Promise<T>;
    reject: (reason?: T) => void;
    resolve: (value: T | PromiseLike<T>) => void;
    constructor();
}
