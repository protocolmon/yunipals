import { Observable, OperatorFunction } from 'rxjs';
export declare const waitFor: <T>(observable: Observable<T>) => Promise<T[]>;
export declare const bufferCountTime: <T>(count: number, time: number) => OperatorFunction<T, T[]>;
