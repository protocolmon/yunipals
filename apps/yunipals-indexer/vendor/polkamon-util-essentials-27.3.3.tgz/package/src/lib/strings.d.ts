export declare const toCamelCase: (input: string) => string;
export declare const removeSpaces: (input: string) => string;
