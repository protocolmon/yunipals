# util-essentials

This library contains very basic code snippets without any dependencies.
