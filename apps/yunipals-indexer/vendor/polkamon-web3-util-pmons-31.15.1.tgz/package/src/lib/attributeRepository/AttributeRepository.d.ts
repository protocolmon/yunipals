import { Attributes } from '@polkamon/web3-util-core';
import { AttributeName, AttributeRecord } from '../attributes';
import { MonsterCodeDefinition } from '../schema';
import { MonsterType } from '../type';
import { AttributeDescription, AttributeReposetoryInterface, ResolveParams, ResolverFactory, TypeResolveParams } from './types';
declare class AttributeRepositoryImpl implements AttributeReposetoryInterface {
    private resolverMap;
    constructor(resolverMap: Record<AttributeName, ResolverFactory>);
    resolveAllBy: (desc: AttributeDescription, search?: ResolveParams) => AttributeRecord | undefined;
    getAllByIds: (desc: AttributeDescription, ids: string[]) => AttributeRecord | undefined;
    resolveType: (search: TypeResolveParams) => MonsterType | undefined;
    resolveTypeByAttrs: (attributes: Attributes) => MonsterType | undefined;
    resolveTypeByCodes: (codes: MonsterCodeDefinition) => MonsterType | undefined;
    private getProvider;
    private combineWithAddtionalAttrs;
}
export declare const AttributeRepository: AttributeRepositoryImpl;
export default AttributeRepository;
