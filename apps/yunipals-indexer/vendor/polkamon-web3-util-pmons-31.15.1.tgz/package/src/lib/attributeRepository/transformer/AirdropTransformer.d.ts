import { Attribute, Trait } from '@polkamon/web3-util-core';
import { PmonAttributes } from '../../types';
import { AttributeTransformer } from '../types';
import { DefaultTransformer } from './DefaultTransformer';
export declare class AirdropTransformer extends DefaultTransformer implements AttributeTransformer {
    toTraits: ({ value }: Attribute) => Trait[];
    toAttributes: ({ value }: Trait, attrName: string) => PmonAttributes;
}
