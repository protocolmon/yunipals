import { Attribute, Attributes, Trait } from '@polkamon/web3-util-core';
import { AttributeDefinitions, AttributeName, AttributeRecord, AttributeValues } from '../attributes/shared';
import { AttributeSchema, MonsterCodeDefinition } from '../schema';
import { MonsterType } from '../type';
import { PmonAttributes, Polyboosterable } from '../types';
export type CompareField = 'code' | 'name' | 'id';
export interface AttributeDescription<T extends AttributeName = AttributeName> {
    attrName: T;
    allowedIds: string[];
}
export interface ResolveParams {
    field?: CompareField;
    value: string | number;
    attributeSiblings?: Attributes;
}
export interface GetAttributeWithIdParams {
    description: AttributeDescription;
    id: string;
}
export interface AttributeResolver {
    getAll(): AttributeRecord | undefined;
    getAllByIds(ids: string[]): AttributeRecord | undefined;
    getById(id: string): AttributeRecord | undefined;
    resolveOneBy(params: ResolveParams): AttributeValues | undefined;
    isOptional(): boolean;
}
export type ResolverFactory = (desc: AttributeDescription) => AttributeResolver;
export type TypeResolveParams = ({
    field: 'id';
} | {
    field: 'code' | 'name';
    attributeSiblings: Attributes;
}) & {
    value: string;
};
export interface AttributeReposetoryInterface {
    /**
     * Resolve the searched attribute for the given params. You can define which field shall be used to compare the value with.
     *
     * This method takes the schema and additional attributes into account.
     *
     * If no search value is provided and the schema does have only ONE value defined this is taken. Otherwise the method returns undefined.
     */
    resolveAllBy(desc: AttributeDescription, search?: ResolveParams): AttributeRecord | undefined;
    /**
     * Get all attributes simply by there ids without any modifications.
     */
    getAllByIds(desc: AttributeDescription, ids: string[]): AttributeRecord | undefined;
    /**
     * Resolve the type by simple search per property in the known types.
     * As the type is a special attribute which defines the schema we add this helper method.
     */
    resolveType(search: TypeResolveParams): MonsterType | undefined;
    /**
     * Resolve the type by a set off attributes. The type in the attributes is used as basis.
     *
     * As the type is a special attribute which defines the schema we add this helper method.
     */
    resolveTypeByAttrs(attributes: Attributes): MonsterType | undefined;
    /**
     * Resolve the type by a monster code. The code is transformed to attributes and then the type is resolved.
     *
     * As the type is a special attribute which defines the schema we add this helper method.
     */
    resolveTypeByCodes(codes: MonsterCodeDefinition): MonsterType | undefined;
}
export interface AttributeTransformer<T extends AttributeValues = AttributeValues> {
    toTraits(attribute: Attribute, attrName: string, allAttrs?: Attributes): Trait[];
    defToTraits(definition: T, attrName: string, allAttrs?: AttributeDefinitions): Trait[];
    toAttributes(trait: Trait, attrName: string, allAttrs?: Trait[]): PmonAttributes;
    defToAttributes(definition: T, attrName: string, allAttrs?: AttributeDefinitions): PmonAttributes;
}
export type TransformingExtraData = Polyboosterable;
export interface AttributeTransforming {
    toTraits(attributes: PmonAttributes, extra?: TransformingExtraData): Trait[];
    defsToTraits(definitions: AttributeDefinitions, extra?: TransformingExtraData): Trait[];
    toAttributes(traits: Trait[], extra?: TransformingExtraData): PmonAttributes;
    defsToAttributes(definitions: AttributeDefinitions, extra?: TransformingExtraData): PmonAttributes;
    toDef(schema: AttributeSchema, attributes: PmonAttributes, extra?: TransformingExtraData): AttributeDefinitions;
}
