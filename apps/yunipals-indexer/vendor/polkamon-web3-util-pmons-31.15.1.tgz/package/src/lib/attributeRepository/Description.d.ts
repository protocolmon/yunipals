import { AttributeName } from '../attributes';
import { PartialAttributeSchema } from '../schema';
import { AttributeDescription } from './types';
export declare class Description implements AttributeDescription {
    private schema;
    attrName: string;
    allowedIds: any[];
    constructor(schema: PartialAttributeSchema, attrName: string);
}
export declare class FixedDescription<T extends AttributeName = AttributeName> implements AttributeDescription<T> {
    allowedIds: string[];
    attrName: T;
    constructor(allowedIds: string[], attrName: T);
}
export declare const describeAttr: (schema: PartialAttributeSchema, attrName: AttributeName) => AttributeDescription;
export default describeAttr;
