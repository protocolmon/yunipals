import { Attribute, Attributes, Trait } from '@polkamon/web3-util-core';
import { PmonAttributes } from '../../types';
import { AttributeTransformer } from '../types';
import { DefaultTransformer } from './DefaultTransformer';
export declare class EditionTransformer extends DefaultTransformer implements AttributeTransformer {
    toTraits: ({ value, type }: Attribute, attrName: string, allAttrs: Attributes) => Trait[];
    toAttributes: ({ value, display_type }: Trait, attrName: string, allAttrs: Trait[]) => PmonAttributes;
    private isFirstEdition;
    private isNFBRelated;
}
