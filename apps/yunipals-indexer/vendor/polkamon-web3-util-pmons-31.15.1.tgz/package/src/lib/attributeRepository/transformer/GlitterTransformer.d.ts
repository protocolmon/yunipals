import { Attribute, Trait } from '@polkamon/web3-util-core';
import { PmonAttributes } from '../../types';
import { AttributeTransformer } from '../types';
import { DefaultTransformer } from './DefaultTransformer';
export declare class GlitterTransformer extends DefaultTransformer implements AttributeTransformer {
    toTraits: ({ value }: Attribute) => Trait[];
    toAttributes: ({ value, display_type }: Trait, attrName: string) => PmonAttributes;
    replaceDeprecatedGlitter: (traits: Trait[]) => void;
    private verifyValue;
}
