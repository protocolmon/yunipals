import { AttributeRecord, AttributeValues } from '../../attributes/shared';
import { AttributeDescription, AttributeResolver, ResolveParams, ResolverFactory } from '../types';
export declare class DefaultAttributeResolver<T extends Record<string, AttributeValues>> implements AttributeResolver {
    private attributes;
    private desc;
    private optional;
    constructor(attributes: T, desc: AttributeDescription, optional?: boolean);
    isOptional: () => boolean;
    getAll: () => AttributeRecord | undefined;
    getAllByIds: (ids: string[]) => AttributeRecord | undefined;
    getById: (id: string) => AttributeRecord | undefined;
    resolveOneBy: (params: ResolveParams | undefined) => AttributeValues | undefined;
}
export declare const resolverFactory: <T extends Record<string, AttributeValues>>(attributes: T) => ResolverFactory;
export default resolverFactory;
