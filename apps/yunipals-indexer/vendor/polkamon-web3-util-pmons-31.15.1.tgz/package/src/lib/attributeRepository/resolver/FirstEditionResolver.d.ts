import { AttributeRecord, AttributeValues } from '../../attributes/shared';
import { AttributeDescription, AttributeResolver, ResolveParams } from '../types';
export declare class FirstEditionResolver implements AttributeResolver {
    private _;
    private wrappedResolver;
    constructor(_: AttributeDescription<'firstEdition' | 'edition'>);
    isOptional: () => boolean;
    getAll: () => AttributeRecord | undefined;
    getAllByIds: (ids: string[]) => AttributeRecord | undefined;
    /**
     * Find the requested attribute. In rare cases one attribute might produces multiple attributes.
     * The resolving should be moved to the dedicated attribtes in the future.
     */
    getById: (id: string) => AttributeRecord | undefined;
    resolveOneBy: (params: ResolveParams) => AttributeValues | undefined;
}
export declare const firstEditionResolverFactory: (desc: AttributeDescription<'firstEdition'>) => FirstEditionResolver;
export default firstEditionResolverFactory;
