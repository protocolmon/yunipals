import { Attribute, Attributes, Trait } from '@polkamon/web3-util-core';
import { AttributeDefinitions, AttributeValues } from '../../attributes';
import { PmonAttributes } from '../../types';
import { AttributeTransformer } from '../types';
export declare class DefaultTransformer implements AttributeTransformer {
    private notTrait;
    constructor(notTrait?: boolean);
    defToTraits: (definition: AttributeValues, attrName: string, _allAttrs?: AttributeDefinitions) => Trait[];
    toTraits: ({ value, type }: Attribute, attrName: string, _allAttrs?: Attributes) => Trait[];
    defToAttributes: (definition: AttributeValues, attrName: string, _allAttrs?: AttributeDefinitions) => PmonAttributes;
    toAttributes: ({ value, display_type }: Trait, attrName: string, _allAttrs?: Trait[]) => PmonAttributes;
}
