import { Attributes, Trait } from '@polkamon/web3-util-core';
import { AttributeDefinitions, AttributeName } from '../../attributes';
import { AttributeSchema } from '../../schema';
import { AttributeTransformer, AttributeTransforming, TransformingExtraData } from '../types';
export declare class AttributeTransformerImpl implements AttributeTransforming {
    private transformerMap;
    constructor(transformerMap: Partial<Record<AttributeName, AttributeTransformer>>);
    toTraits(attributes: Attributes, extra?: TransformingExtraData): Trait[];
    defsToTraits(definitions: AttributeDefinitions, extra?: TransformingExtraData): Trait[];
    toAttributes(traits: Trait[], extra?: TransformingExtraData): Attributes;
    defsToAttributes(definitions: AttributeDefinitions, extra?: TransformingExtraData): Attributes;
    toDef(schema: AttributeSchema, attributes: Attributes, extra?: TransformingExtraData): AttributeDefinitions | undefined;
    protected getTransformer(attrName: string): AttributeTransformer;
}
export declare const AttributeTransformingUtils: AttributeTransformerImpl;
export default AttributeTransformingUtils;
