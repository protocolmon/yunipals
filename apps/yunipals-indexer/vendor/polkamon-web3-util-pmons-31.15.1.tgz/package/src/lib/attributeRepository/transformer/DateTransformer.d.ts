import { Trait } from '@polkamon/web3-util-core';
import { AttributeValues } from '../../attributes';
import { PmonAttributes } from '../../types';
import { AttributeTransformer } from '../types';
import { DefaultTransformer } from './DefaultTransformer';
export declare class DateTransformer extends DefaultTransformer implements AttributeTransformer {
    defToTraits: (definition: AttributeValues, attrName: string) => Trait[];
    defToAttributes: (definition: AttributeValues, attrName: string) => PmonAttributes;
}
