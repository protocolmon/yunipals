import { AttributeRecord, AttributeValues } from '../../attributes/shared';
import { MonsterCodeDefinition } from '../../schema';
import { MonsterType } from '../../type';
import { AttributeDescription, AttributeResolver, ResolveParams } from '../types';
export declare class TypeResolver implements AttributeResolver {
    private desc;
    private wrappedResolver;
    constructor(desc: AttributeDescription<'type'>);
    isOptional: () => boolean;
    getAll: () => AttributeRecord | undefined;
    getAllByIds: (ids: string[]) => AttributeRecord | undefined;
    /**
     * Find the requested attribute. In rare cases one attribute might produces multiple attributes.
     * The resolving should be moved to the dedicated attribtes in the future.
     */
    getById: (id: string) => AttributeRecord | undefined;
    resolveOneBy: (params: ResolveParams) => AttributeValues | undefined;
    resolveOneByCode: (codes: MonsterCodeDefinition) => MonsterType | undefined;
    private resolveTypeByAttributes;
}
export declare const allTypesDesc: () => AttributeDescription<'type'>;
export declare const typeResolverFactory: (desc: AttributeDescription<'type'>) => TypeResolver;
export default typeResolverFactory;
