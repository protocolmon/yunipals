import { AttributeRecord, AttributeValues } from '../../attributes/shared';
import { AttributeDescription, AttributeResolver, ResolveParams } from '../types';
export declare class AirdropResolver implements AttributeResolver {
    private _;
    private wrappedResolver;
    constructor(_: AttributeDescription<'Airdrop'>);
    isOptional: () => boolean;
    getAll: () => AttributeRecord | undefined;
    getAllByIds: (ids: string[]) => AttributeRecord | undefined;
    /**
     * Find the requested attribute. In rare cases one attribute might produces multiple attributes.
     * The resolving should be moved to the dedicated attribtes in the future.
     */
    getById: (id: string) => AttributeRecord | undefined;
    resolveOneBy: (params: ResolveParams) => AttributeValues | undefined;
}
export declare const airdropResolverFactory: (desc: AttributeDescription<'Airdrop'>) => AirdropResolver;
export default airdropResolverFactory;
