import { Attributes, Trait } from '@polkamon/web3-util-core';
import { AttributeDefinitions } from '../../attributes';
import { TransformingExtraData } from '../types';
import { AttributeTransformerImpl } from './AttributeTransforming';
export declare class PublicAttributeTransformerImpl extends AttributeTransformerImpl {
    constructor();
    toTraits(attributes: Attributes, extra?: TransformingExtraData): Trait[];
    defsToTraits(definitions: AttributeDefinitions, extra?: TransformingExtraData): Trait[];
    private addAdditionalTraits;
}
export declare const PublicAttributeTransformingUtils: PublicAttributeTransformerImpl;
