import { AttributeName } from '../../attributes';
import { AttributeTransformer } from '../types';
export declare const DefaultTransformerMap: Partial<Record<AttributeName, AttributeTransformer>>;
