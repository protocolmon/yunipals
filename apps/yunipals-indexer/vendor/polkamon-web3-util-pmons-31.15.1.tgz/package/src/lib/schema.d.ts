import { Attributes } from '@polkamon/web3-util-core';
import { ColorCode, MonsterType } from '..';
import { AmountCode, AmountIds, AttributeDefinitions, AttributeName, BackgroundCode, BackgroundIds, ColorIds, DeprecatedEditionIds, GlitterCode, GlitterIds, HornCode, HornIds, IsSpecialIds, OriginDef, OriginDef2, OriginDef3, OriginDef4, OriginDef5, OriginDef6, TimeCode, TimeIds, VariantCode, VariantIds } from './attributes';
import { ExomonCelestialIds } from './attributes/exomon/celestial';
import { SoundIds } from './attributes/sound';
import { MonsterCodes, MonsterNames } from './type';
export declare const MONSTER_CODE_REGEX: RegExp;
export interface MonsterCodeDefinition {
    type: MonsterCodes;
    color: ColorCode;
    background: BackgroundCode;
    horn: HornCode;
    glitter: GlitterCode;
    variant?: VariantCode;
    amount?: AmountCode;
    time?: TimeCode;
}
export interface FullAttributeDefinitions extends AttributeDefinitions {
    type: MonsterType;
}
type AllAttibuteTypes = HornIds | ColorIds | BackgroundIds | GlitterIds | IsSpecialIds | DeprecatedEditionIds | VariantIds | AmountIds | TimeIds | ExomonCelestialIds | string;
export type PartialAttributeSchema = Partial<Record<AttributeName, readonly AllAttibuteTypes[]>>;
export interface AttributeSchema extends PartialAttributeSchema {
    color: readonly ColorIds[];
    background: readonly BackgroundIds[];
    horn?: readonly HornIds[];
    glitter?: readonly GlitterIds[];
    special?: readonly IsSpecialIds[];
    edition?: readonly DeprecatedEditionIds[];
    variant?: readonly VariantIds[];
    sound?: readonly SoundIds[];
    amount?: readonly AmountIds[];
    time?: readonly TimeIds[];
    origin?: OriginDef;
    origin2?: OriginDef2;
    origin3?: OriginDef3;
    origin4?: OriginDef4;
    origin5?: OriginDef5;
    origin6?: OriginDef6;
    celestial?: readonly ExomonCelestialIds[];
}
export declare const getSchemaByName: (name: MonsterNames) => AttributeSchema | undefined;
export type SelectedAttributes = Partial<Record<AttributeName, string>>;
/**
 * Generate a full monster attribute description with full attribute schema based on a set of attributes in the form as they are stored in the database.
 *
 * Missing selected are resolved from the schema if only 1 option is present.
 */
export declare const generateAttributeDefinitionByAttributes: (type: MonsterType, selected: Attributes) => FullAttributeDefinitions | undefined;
/**
 * Generate a full monster attribute description with full attribute schema based on a set of attribute names.
 *
 * Missing selected are resolved from the schema if only 1 option is present.
 */
export declare const generateAttributeDefinition: (type: MonsterType, preSelected: SelectedAttributes) => FullAttributeDefinitions | undefined;
export declare const generateAttributeDefinitionByCode: (code: string) => FullAttributeDefinitions;
export declare const generateCodeByAttributes: (type: MonsterType, selected: Attributes) => string | undefined;
export declare const generateCodeByAttributesWithType: (attrs: Attributes) => string | undefined;
export declare const generateCode: (type: MonsterType, attrs: AttributeDefinitions) => string | undefined;
export declare const generateAllCodes: (type: MonsterType) => string[];
export declare const generateAllVariants: (type: MonsterType) => AttributeDefinitions[];
/**
 * Check if the given attributes are all allowed in the given schema. All values can be found in the schema.
 * More attributes are allowed.
 */
export declare const matchesSchema: (schema: AttributeSchema, attributes: Attributes) => boolean;
/**
 * same as matchesSchema based on codes
 */
export declare const matchesSchemaByCodes: (schema: AttributeSchema, codes: MonsterCodeDefinition) => boolean;
export {};
