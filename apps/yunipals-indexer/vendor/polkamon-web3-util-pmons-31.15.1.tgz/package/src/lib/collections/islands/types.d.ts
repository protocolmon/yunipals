import { Attributes, NFT } from '@polkamon/web3-util-core';
import { RawMetadata } from '../../transaction';
import { IslandCodes } from '../../type/island';
export type IslandAttributeName = string;
export type IslandAttributes = Attributes<IslandAttributeName>;
export type Island = NFT<IslandAttributeName>;
export type IslandMetadata = RawMetadata & {
    code: IslandCodes;
};
