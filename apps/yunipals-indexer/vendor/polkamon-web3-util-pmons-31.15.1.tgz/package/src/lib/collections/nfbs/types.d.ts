import { Attributes, Chain, ChainGroup, GenerationId, GiftData, NFBSourceInfo, NFT } from '@polkamon/web3-util-core';
import { RawMetadata } from '../../transaction';
export type NFBAttributeName = 'series' | 'seriesId' | 'edition' | 'boosterId';
export type NFBAttributes = Attributes<NFBAttributeName>;
export type NFB = NFT<NFBAttributeName> & {
    giftCard?: {
        sender: string;
        message: string;
    };
};
export interface NFBMetadata extends RawMetadata, NFBSourceInfo {
    hash: string;
    chainGroup: ChainGroup;
}
export interface NFBMetadataResolver {
    resolve: (chain: Chain, tokenId: string) => Promise<NFBMetadata | undefined>;
    resolveGenId: (chain: Chain, tokenId: string) => Promise<GenerationId | undefined>;
    resolveGift: (chain: Chain, transactionHash: string) => Promise<GiftData | undefined>;
}
