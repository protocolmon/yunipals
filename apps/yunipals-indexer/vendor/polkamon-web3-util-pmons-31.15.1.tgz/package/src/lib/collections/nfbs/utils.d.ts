import { NFBOrigins, NFBSourceInfo } from '@polkamon/web3-util-core';
import { NFBMetadata } from './types';
export declare const extractNFBInfo: (prefix: NFBOrigins, { id, attributes }: NFBMetadata) => NFBSourceInfo;
