import { Metadata, SOURCE_NETWORK } from '../transaction';
export interface RainbowMetadata extends Metadata {
    code: string;
    targetNetwork: SOURCE_NETWORK;
    createdAt: Date;
    originIds: string[];
    origins: Metadata[];
    originScore: number;
}
