import { SimpleTransaction, TransactionMetadata, TransactionOnChain } from '../transaction';
export type StakingMetadata = TransactionMetadata;
export interface StakingTransaction extends SimpleTransaction<StakingMetadata>, TransactionOnChain {
    stakedAmount: number;
    lockDays: number;
    randomNumber: string;
}
export type UnsavedStakingTransaction = Omit<StakingTransaction, '_id'>;
