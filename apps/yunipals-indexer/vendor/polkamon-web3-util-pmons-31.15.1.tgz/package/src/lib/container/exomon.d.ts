import { Metadata } from '../transaction';
export interface ExomonMetadata extends Metadata {
    code: string;
    pfpUrl: string;
    createdAt: Date;
}
