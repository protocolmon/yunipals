import { Metadata, SOURCE_NETWORK } from '../transaction';
export interface CrystalMetadata extends Metadata {
    targetNetwork: SOURCE_NETWORK;
}
