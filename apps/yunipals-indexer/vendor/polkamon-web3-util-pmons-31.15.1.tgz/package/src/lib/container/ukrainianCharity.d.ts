import { Metadata } from '../transaction';
export type UkrainianCharityMetadata = Metadata;
