import { Metadata } from '../transaction';
export type LaunchSpecialMetadata = Metadata;
