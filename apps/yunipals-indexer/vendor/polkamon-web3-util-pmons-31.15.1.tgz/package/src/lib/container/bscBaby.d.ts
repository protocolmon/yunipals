import { Metadata } from '../transaction';
export type BscBabiesMetadata = Metadata;
