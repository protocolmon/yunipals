import { BoosterTransaction } from './booster';
export type GhostBoosterTransaction = BoosterTransaction;
