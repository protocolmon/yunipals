import { MultiTransaction, TransactionMetadata, TransactionOnChain } from '../transaction';
export type AirdropTransaction = MultiTransaction<AirdropMetadata>;
export type UnsavedAirdropTransaction = Omit<AirdropTransaction, '_id'>;
export interface BoosterTransaction extends MultiTransaction<BoosterMetadata>, TransactionOnChain {
    randomNumbers: string[];
    boosterIds: number[];
    amount: string;
    openedBoosters: number;
    softMintHash: string;
}
export type UnsavedBoosterTransaction = Omit<BoosterTransaction, '_id'>;
export type AirdropMetadata = TransactionMetadata;
export interface BoosterMetadata extends TransactionMetadata {
    boosterId: number;
    randomNumber: string;
    edition?: string;
}
