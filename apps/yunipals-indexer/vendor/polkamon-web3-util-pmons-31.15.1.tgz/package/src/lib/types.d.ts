import { Attributes, NFT, NFTEnvelope, Origin } from '@polkamon/web3-util-core';
import { AttributeName } from './attributes';
import { Playabale } from './game';
import { RandomItem, Rare } from './rarity/types';
import { MonsterIds, MonsterIdsWithExperimental } from './type';
export type PmonAttributes = Attributes<AttributeName>;
interface BoosterItem {
    boosterId?: number;
}
interface HadGift {
    giftRedeemed?: boolean;
}
export type PMON = NFT<AttributeName, MonsterIds | MonsterIdsWithExperimental> & Rare & OnAdventure & BoosterItem & Playabale & HadGift & Polyboosterable;
export type PMONOnChain = PMON & RandomItem;
export interface PMONFromBooster extends PMONOnChain {
    boosterId: number;
}
export interface PMONForStaking extends PMONOnChain {
    stakedAmount: number;
    lockDays: number;
}
export interface PMONFromFusion extends PMON {
    originIds: string[];
    originScore: number;
}
export interface PMONFusionOrigin extends Origin {
    originIds: string[];
    originScore: number;
}
export declare enum AdventureNftStatus {
    READY_FOR_ADVENTURE = "READY_FOR_ADVENTURE",
    ON_ADVENTURE = "ON_ADVENTURE",
    NOT_PARTICIPATING = "NOT_PARTICIPATING"
}
export interface OnAdventure {
    adventureStatus?: AdventureNftStatus;
    axpCount?: number;
    adventureTitle?: string;
    adventureId?: string;
}
declare const POLYBOOST_STATE: readonly ["UNSTAKED", "STAKED", "WITHDRAWABLE"];
export declare const PolyboostState: ReadonlyArray<PolyboostState>;
export type PolyboostState = (typeof POLYBOOST_STATE)[number];
export interface PolyboostPosition {
    state: PolyboostState;
    pool: number;
    level: number;
    stakedBalance: number;
    stakedBalanceWithMultipliers: number;
    inLevelSince: Date;
    boostingSince: Date;
    withdrawableTime: Date;
}
export interface Polyboosterable {
    polyboostPosition?: PolyboostPosition;
}
export type BoosterEnvelop = NFTEnvelope<PMONFromBooster>;
export {};
