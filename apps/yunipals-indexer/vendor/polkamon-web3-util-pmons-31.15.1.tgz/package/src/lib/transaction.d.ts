import { Chain, ChainGroup, SlimChain, Trait } from '@polkamon/web3-util-core';
import { InitialProbabilities } from './rarity/types';
export type SOURCE_NETWORK = 'MATIC' | 'ETHEREUM' | 'BSC' | 'SOLANA' | 'ARBITRUM' | 'ARBITRUM_NOVA' | 'OPTIMISM' | 'BASE';
export interface RawMetadata {
    id: string;
    image: string;
    external_url: string;
    description: string;
    name: string;
    attributes: Trait[];
    animation_url: string;
}
export interface Metadata extends RawMetadata {
    background_color: string;
    initialProbabilities: InitialProbabilities;
}
export interface TransactionMetadata extends Metadata {
    txHash: string;
}
export interface Transaction {
    _id: string;
    hasError: boolean;
    done: boolean;
    hash: string;
    targetNetwork: SOURCE_NETWORK;
    createdAt: Date;
    updatedAt: Date;
}
export interface TransactionOnChain {
    hasError: boolean;
    isConfirmed: boolean;
    blockNumber: number;
    nonce: number;
    randomNumberRequestedAt: Date;
    randomNumbersReadAt: Date;
    targetAddress: string;
}
export interface MultiTransaction<T extends TransactionMetadata = TransactionMetadata> extends Transaction {
    metaDatas: T[];
}
export interface SimpleTransaction<T extends TransactionMetadata = TransactionMetadata> extends Transaction {
    metaData: T;
}
export declare const toSlimChain: (source: SOURCE_NETWORK, onTestnet: boolean) => SlimChain | undefined;
export declare const asSlimChain: (chain: Chain | SlimChain) => SlimChain | undefined;
export declare const toChain: (source: SOURCE_NETWORK, onTestnet: boolean) => Chain | undefined;
export declare const fromChainGroup: (chainGroup: ChainGroup) => SOURCE_NETWORK;
