import { ValueProvider } from '../rarity/score';
import { BoolIds, BoolNames, RawAttributeValue } from './shared';
export type FirstEditionIds = BoolIds;
export type FirstEditionNames = BoolNames;
export declare const FirstEditionIds: readonly ["yes", "no"];
export type FirstEdition = RawAttributeValue<FirstEditionIds, BoolNames> & {
    multiplier: number;
};
export declare const FirstEditions: Record<FirstEditionIds, FirstEdition>;
export declare const firstEditionMultiplier: ValueProvider;
