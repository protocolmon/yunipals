import { AttributeProvider } from '../type';
import { BoolIds, BoolNames, RawAttributeValue } from './shared';
export type IsAirdropIds = BoolIds;
export declare const IsAirdropIds: ReadonlyArray<IsAirdropIds>;
export type IsAirdropNames = BoolNames;
export declare const IsAirdropNames: ReadonlyArray<IsAirdropNames>;
export type IsAirdrop = RawAttributeValue<IsAirdropIds, IsAirdropNames>;
export declare const Airdrops: Record<IsAirdropIds, IsAirdrop>;
export declare const isAirdropByAttrs: ({ attributes }: AttributeProvider) => boolean;
