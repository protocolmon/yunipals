import { BaseGlitter } from '../glitter';
/**
 * We should steadly move all standards to this new namespace. As this provides us the possiblity to build aggreations
 * in other modules like in the rainbow glitters. Otherwise we might get curcular module dependancies.
 *
 * On top level we only should provide aggregations and helper utils.
 */
declare const STANDARD_GLITTER_IDS: readonly ["none", "glitter"];
export type StandardGlitterIds = (typeof STANDARD_GLITTER_IDS)[number];
export declare const StandardGlitterIds: ReadonlyArray<StandardGlitterIds>;
declare const STANDARD_GLITTER_NAMES: readonly ["None", "Glitter"];
export type StandardGlitterNames = (typeof STANDARD_GLITTER_NAMES)[number];
export declare const StandardGlitterNames: ReadonlyArray<StandardGlitterNames>;
export type StandardGlitterCode = 'G00' | 'G01';
export type StandardGlitter = BaseGlitter<StandardGlitterIds, StandardGlitterNames, StandardGlitterCode>;
export declare const StandardGlitters: Record<StandardGlitterIds, StandardGlitter>;
export {};
