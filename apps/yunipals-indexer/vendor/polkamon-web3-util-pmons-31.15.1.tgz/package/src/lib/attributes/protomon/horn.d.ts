import { BaseHorn } from '../horn';
import { StandardHornIds } from '../standard/horn';
declare const PROTOMON_HORN_IDS: readonly ["silverCurved", "normal", "wide", "twistedWood", "spearhead", "ivoryCurl", "diamond"];
export type ProtomonHornIds = (typeof PROTOMON_HORN_IDS)[number];
export declare const ProtomonHornIds: ReadonlyArray<ProtomonHornIds>;
export declare const PROTOMON_HORN_NAMES: readonly ["Silver Curved", "Normal", "Wide", "Twisted Wood", "Spearhead", "Ivory Curl", "Diamond"];
export type ProtomonHornNames = (typeof PROTOMON_HORN_NAMES)[number];
export declare const ProtomonHornNames: ReadonlyArray<ProtomonHornNames>;
export type ProtomonHornCode = 'H01' | 'H02' | 'H04' | 'H05' | 'H06' | 'H09' | 'H10';
export type ProtomonHorn = BaseHorn<ProtomonHornIds, ProtomonHornNames, ProtomonHornCode> & {
    newHornId: StandardHornIds;
};
export declare const ProtomonHorns: Record<ProtomonHornIds, ProtomonHorn>;
export {};
