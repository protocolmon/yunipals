import { StandardGlitter, StandardGlitterCode } from '../standard/glitter';
import { MultiplierAttributeValue } from '../shared';
declare const DEPRECATED_GLITTER_IDS: readonly ["yes", "no"];
export declare const DeprecatedGlitterIds: ReadonlyArray<DeprecatedGlitterIds>;
export type DeprecatedGlitterIds = (typeof DEPRECATED_GLITTER_IDS)[number];
declare const DEPRECATED_GLITTER_NAMES: readonly ["Yes", "No"];
export type DeprecatedGlitterNames = (typeof DEPRECATED_GLITTER_NAMES)[number];
export declare const DeprecatedGlitterNames: ReadonlyArray<DeprecatedGlitterNames>;
export type DeprecatedGlitter = MultiplierAttributeValue<DeprecatedGlitterIds, DeprecatedGlitterNames, StandardGlitterCode> & {
    aliasFor: StandardGlitter;
};
export declare const DeprecatedGlitters: Record<DeprecatedGlitterIds, DeprecatedGlitter>;
export {};
