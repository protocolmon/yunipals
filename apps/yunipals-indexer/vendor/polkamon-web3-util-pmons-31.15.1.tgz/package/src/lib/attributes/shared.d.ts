import { Attribute } from '@polkamon/web3-util-core';
import { GameAttributeRank, GameProperties } from '../game';
import { NFBAttributeName } from '../collections/nfbs';
import { Amount } from './amount';
import { Background } from './background';
import { Color } from './color';
import { DeprecatedEdition } from './deprecated';
import { ExomonCelestial } from './exomon/celestial';
import { FirstEdition } from './firstEdition';
import { Glitter } from './glitter';
import { Horn } from './horn';
import { Origin } from './origin';
import { Sound } from './sound';
import { Time } from './time';
import { Variant } from './variant';
export type AttributeCollections<IDS extends string> = Record<IDS, AttributeValue<IDS, string, string>>;
export interface AttributeDefinitions extends AttributeRecord {
    edition?: DeprecatedEdition;
    firstEdition?: FirstEdition;
    horn?: Horn;
    time?: Time;
    variant?: Variant;
    sound?: Sound;
    glitter: Glitter;
    amount?: Amount;
    background: Background;
    color: Color;
    origin?: Origin;
    origin2?: Origin;
    origin3?: Origin;
    origin4?: Origin;
    origin5?: Origin;
    origin6?: Origin;
    celestial?: ExomonCelestial;
}
export type AttributeRecord = Partial<Record<AttributeName, AttributeValues>>;
export type AttributeValues = BoolAttributeValue | AttributeValue | RawAttributeValue;
export type AttributeName = 'special' | 'birthday' | 'type' | 'horn' | 'color' | 'glitter' | 'firstEdition' | 'sound' | 'booster' | 'background' | 'rarity' | 'rarityCapped' | 'origin' | 'origin2' | 'origin3' | 'origin4' | 'origin5' | 'origin6' | 'airdrop' | NFBAttributeName | string;
export type AttributeGroup = 'rainbow' | 'exomon' | 'mutants' | 'ghost' | 'binanceBabies' | 'protomon' | 'crystal';
export interface MultiplierAttributeValue<IDS extends string = string, NAMES extends string = string, CODES extends string = string> extends AttributeValue<IDS, NAMES, CODES> {
    rainbowMultiplier?: number;
}
export interface AttributeValue<IDS extends string = string, NAMES extends string = string, CODES extends string = string> extends GameAttributeValue<IDS, NAMES>, RarityAttributeValue<IDS, NAMES> {
    code: CODES;
}
export interface GameAttributeValue<IDS extends string = string, NAMES extends string = string> extends RawAttributeValue<IDS, NAMES> {
    gameProps?: GameProperties;
    rank: GameAttributeRank;
}
export interface RarityAttributeValue<IDS extends string = string, NAMES extends string = string> extends RawAttributeValue<IDS, NAMES> {
    initialRarity: number;
    rarity: number;
    collectorRarity: number;
}
export interface RawAttributeValue<IDS extends string = string, NAMES extends string = string> {
    id: IDS;
    name: NAMES;
    unreleased?: boolean;
    group?: AttributeGroup;
    deprecated?: boolean;
    additionalAttributes?: AttributeRecord;
}
declare const BOOL_IDS: readonly ["yes", "no"];
export type BoolIds = (typeof BOOL_IDS)[number];
export declare const BoolIds: readonly ["yes", "no"];
declare const BOOL_NAMES: readonly ["Yes", "No"];
export type BoolNames = (typeof BOOL_NAMES)[number];
export declare const BoolNames: readonly ["Yes", "No"];
export type BoolAttributeValue<CODES extends string = string> = AttributeValue<BoolIds, BoolNames, CODES>;
export declare const defaultRarityWith: <IDS extends string, T extends AttributeCollections<IDS>>(attributes: T, id: IDS, defaultId: IDS) => number;
export declare const defaultRarityByName: <IDS extends string, T extends AttributeCollections<IDS>>(attributes: T, name: string, defaultRarity: number) => number;
export declare const isYes: ({ value }?: Attribute) => boolean;
export {};
