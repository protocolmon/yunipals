import { ValueProvider } from '../../rarity/score';
import { FirstEdition } from '../firstEdition';
import { RawAttributeValue } from '../shared';
/**
 * @deprecated
 *
 * Editions are deprecated. As we only have FirstEdition yes no. But we currently need them for possible generation of monsters.
 */
export type DeprecatedEditionIds = '0' | '1';
/**
 * @deprecated
 *
 * Editions are deprecated. As we only have FirstEdition yes no. But we currently need them for possible generation of monsters.
 */
export type DeprecatedEditionNames = DeprecatedEditionIds;
/**
 * @deprecated
 *
 * Editions are deprecated. As we only have FirstEdition yes no. But we currently need them for possible generation of monsters.
 */
export type DeprecatedEdition = RawAttributeValue<DeprecatedEditionIds, DeprecatedEditionNames> & {
    multiplier: number;
    aliasFor: FirstEdition;
};
/**
 * @deprecated
 *
 * Editions are deprecated. As we only have FirstEdition yes no. But we currently need them for possible generation of monsters.
 */
export declare const DeprecatedEditions: Record<DeprecatedEditionIds, DeprecatedEdition>;
export declare const editionMultiplier: ValueProvider;
