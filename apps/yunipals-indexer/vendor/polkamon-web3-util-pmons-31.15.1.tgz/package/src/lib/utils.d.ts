/**
 * @deprecated use AttributeTransformingUtils.toAttributes
 */
export declare const traitsToAttributes: (traits: import("../../../../../dist/libs/web3/util-core/src").Trait[], extra?: import("./types").Polyboosterable) => import("../../../../../dist/libs/web3/util-core/src").Attributes;
/**
 * @deprecated use AttributeTransformingUtils.toTraits
 */
export declare const attributesToTraits: (attributes: import("../../../../../dist/libs/web3/util-core/src").Attributes, extra?: import("./types").Polyboosterable) => import("../../../../../dist/libs/web3/util-core/src").Trait[];
/**
 * @deprecated use AttributeTransformingUtils.defsToTraits
 */
export declare const toPmonTraits: (definitions: import("./attributes").AttributeDefinitions, extra?: import("./types").Polyboosterable) => import("../../../../../dist/libs/web3/util-core/src").Trait[];
/**
 * @deprecated use AttributeTransformingUtils.defsToAttributes
 */
export declare const toPmonAttributes: (definitions: import("./attributes").AttributeDefinitions, extra?: import("./types").Polyboosterable) => import("../../../../../dist/libs/web3/util-core/src").Attributes;
