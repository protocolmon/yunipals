import { RareItem } from '.';
export interface Cap {
    from: number;
    to: number;
    maxPoints: number;
}
export interface Options {
    caps: Cap[];
}
export declare const rarityFor: (nft: RareItem, options?: Partial<Options>) => number | undefined;
/**
 * Rainbow Polymons will not only get the rarity score of all the polymons that were merged to create it,
 * they will also be boosted by a specific multiplier that depends on the horn, color and glitter
 * There was a DAO voting about:
 * https://snapshot.org/#/polymon.eth/proposal/0xfbbab22a15a91f15d9a6758a47f1c8f45f839153ccf95af4d6e6c0bbbb0cdd2a
 *
 * For example: Having a black normal glitter Rainbow Unisheep with a Candy Cane horn would get the following boost:
 * Color multiplier (rainbow black): 2x
 * Horn multiplier (candy cane): 1.2x
 * Glitter multiplier (yes): 1.5x
 *
 * Result: (2 + 1.2 + 1.5) / 3 = 1.56
 *
 */
export declare const getRainbowMultipliers: (rainbow: RareItem) => RainbowMultiplier;
export type RainbowMultiplier = {
    colorMultiplier: number;
    hornMultiplier: number;
    glitterMultiplier: number;
    combinedMultiplier: number;
};
