import { PMON } from '../types';
export * from './rarity';
export * from './score';
export * from './types';
export type RareItem = Partial<Pick<PMON, 'initialProbabilities'>> & Pick<PMON, 'id' | 'attributes'> & {
    originScore?: number;
};
