declare const PROBABILITY_NAMES: readonly ["type", "horn", "color", "glitter", "background", "sound"];
export type PROBABILITY_NAMES = (typeof PROBABILITY_NAMES)[number];
export declare const ProbabilityNames: ReadonlyArray<PROBABILITY_NAMES>;
export type InitialProbabilities = Partial<Record<PROBABILITY_NAMES, number>>;
export interface Rare {
    initialRarity: number;
    initialRarityCapped: number;
    initialProbabilities?: InitialProbabilities;
}
export interface RandomItem {
    blockNumber: number;
    nonce: number;
    randomNumber: string;
    randomNumbersRead: Date;
}
export {};
