import { Attribute } from '@polkamon/web3-util-core';
import { RareItem } from '.';
import { AttributeName } from '../attributes';
export type ValueProvider = (attr: Attribute, initialProbability: number) => number;
export type ScoreResolver = ({ initialProbabilities, attributes }: RareItem, name: AttributeName, provider: ValueProvider) => number;
export declare const score: ScoreResolver;
export declare const typeScore: (nft: RareItem) => number;
