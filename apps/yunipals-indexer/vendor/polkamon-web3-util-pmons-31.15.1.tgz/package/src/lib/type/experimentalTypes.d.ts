declare const EXPERIMENTAL_IDS: readonly ["expUnidragon", "expUniaqua", "expUnibranch", "expUnicursed", "expUnidonkey", "expUnichick", "expUniair", "expUniturtle", "expUnisheep", "expUnifairy", "expUnikles"];
export type ExperimentalIds = (typeof EXPERIMENTAL_IDS)[number];
export declare const ExperimentalIds: ReadonlyArray<ExperimentalIds>;
export {};
