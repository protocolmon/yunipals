import { MonsterBaseType } from '.';
import { AttributeSchema } from '../schema';
export type IslandCodes = 'I001' | 'I002' | 'I003' | 'I004' | 'I005' | 'I006';
declare const ISLAND_IDS: readonly ["grasslandGenesisIsland", "grasslandIsland", "yellowStoneGenesisIsland", "yellowStoneIsland", "whiteBeachGenesisIsland", "whiteBeachIsland"];
export type IslandIds = (typeof ISLAND_IDS)[number];
export declare const IslandIds: ReadonlyArray<IslandIds>;
declare const ISLAND_NAMES: readonly ["Grassland Genesis Island", "Grassland Island", "Yellow Stone Genesis Island", "Yellow Stone Island", "White Beach Genesis Island", "White Beach Island"];
export type IslandNames = (typeof ISLAND_NAMES)[number];
export declare const IslandNames: ReadonlyArray<IslandNames>;
export declare const IslandSchema: AttributeSchema;
export type IslandType = MonsterBaseType<IslandIds, IslandNames, IslandCodes> & {
    ipfsImageHash: string;
};
export declare const IslandTypes: Record<IslandIds, IslandType>;
export {};
