import { GameData, GameItem } from './types';
export declare const gameDataFor: ({ id, attributes }: GameItem) => GameData | undefined;
