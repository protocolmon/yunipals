import { PMON } from '../types';
export type GameVersion = 'v0' | 'v1' | 'v2' | 'v3' | 'v4';
export interface GameProperties {
    health: number;
    water: number;
    fire: number;
    earth: number;
    wind: number;
}
declare const GAME_ATTRIBUTE_RANKS: readonly [1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 13, 14, 24];
export type GameAttributeRank = (typeof GAME_ATTRIBUTE_RANKS)[number];
export declare const GameAttributeRanks: ReadonlyArray<GameAttributeRank>;
export interface GameData extends GameProperties {
    version: GameVersion;
    pFactor: number;
    score: number;
    sum: number;
}
export interface Playabale {
    gameData?: GameData;
}
export type GameItem = Pick<PMON, 'id' | 'attributes'>;
export {};
