import { ChainGroup, GiftData, ORIGIN_TYPE, Trait } from '@polkamon/web3-util-core';
import { RainbowMetadata } from '../container';
import { Playabale } from '../game';
import { InitialProbabilities } from '../rarity/types';
import { OnAdventure, Polyboosterable } from '../types';
export interface LegacyMetadataChain {
    nftContract: NftContract;
    chain: ChainShort;
    chainGroup: ChainGroup;
    openingNetwork: string;
}
export type NftContract = 'polychainmonsters' | 'bsc:binanceNFT' | 'solana:exomon' | 'bsc:ukrainianUnidonkey' | 'arbitrum:experimental' | 'arbitrum:experimental:v2' | undefined;
export type ChainShort = 'eth' | 'bsc' | 'polygon' | 'solana' | 'arbitrum' | 'arbitrumNova' | 'base' | 'optimism';
export interface LegacyMetaData extends OnAdventure, Partial<RainbowMetadata>, Playabale, Polyboosterable {
    address?: string;
    animation_url: string;
    attributes: Trait[];
    background_color: string;
    boosterId?: number;
    description: string;
    external_url?: string;
    id: string;
    image: string;
    imageAnimatedUrl: string;
    initialProbabilities?: InitialProbabilities;
    name: string;
    type: string;
    origin?: ORIGIN_TYPE;
    randomNumber?: string;
    txHash?: string;
    edition?: string;
    minted?: boolean;
    bridged?: boolean;
    chain?: ChainShort;
    chainGroup?: ChainGroup;
    originChain?: ChainShort;
    originChainGroup?: ChainGroup;
    nftContract?: NftContract;
    opening_network?: string;
    rarity?: number;
    rarityCapped?: number;
    pfpUrl?: string;
    giftData?: GiftData;
    rafflePriceClaimed?: boolean;
    ownerSince?: Date;
}
