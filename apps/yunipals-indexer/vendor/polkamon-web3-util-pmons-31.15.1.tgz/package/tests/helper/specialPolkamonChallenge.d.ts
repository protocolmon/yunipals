import { PolkamonMock } from './polkamonAttributes';
export declare const scoreForSpecialPolkamon: (polkamon: PolkamonMock) => number | undefined;
