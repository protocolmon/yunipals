"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scoreForPolkamon = void 0;
const lodash_1 = require("lodash");
const polkamonAttributes_1 = require("./polkamonAttributes");
// copy of the staking challenge
const scoreForPolkamon = (polymon) => {
    var _a, _b, _c, _d;
    if (!(0, polkamonAttributes_1.isSpecial)(polymon) && !(0, polkamonAttributes_1.isBinanceBaby)(polymon) && (0, polkamonAttributes_1.getType)(polymon) !== 'Mysterious Egg') {
        const initialR = polymon.initialProbabilities;
        const glitterR = (initialR === null || initialR === void 0 ? void 0 : initialR.glitter) || ((0, polkamonAttributes_1.isGlitter)(polymon) ? polkamonAttributes_1.glitterRarity : polkamonAttributes_1.nonGlitterRarity);
        const colorR = (initialR === null || initialR === void 0 ? void 0 : initialR.color) || ((_a = polkamonAttributes_1.colors[(0, polkamonAttributes_1.getColor)(polymon).toLowerCase()]) === null || _a === void 0 ? void 0 : _a.rarity) || 1;
        const hornR = ((_b = (0, polkamonAttributes_1.getAdditionalHornDef)((0, polkamonAttributes_1.getHorn)(polymon))) === null || _b === void 0 ? void 0 : _b.rarity) || (initialR === null || initialR === void 0 ? void 0 : initialR.horn) || ((_c = (0, polkamonAttributes_1.getHornDef)((0, polkamonAttributes_1.getHorn)(polymon))) === null || _c === void 0 ? void 0 : _c.rarity) || 1;
        const typeR = (initialR === null || initialR === void 0 ? void 0 : initialR.type) || ((_d = (0, polkamonAttributes_1.getTypeDef)((0, polkamonAttributes_1.getType)(polymon))) === null || _d === void 0 ? void 0 : _d.rarity) || 1;
        const firstEditionMul = (0, polkamonAttributes_1.getEdition)(polymon) === 1 ? 1.2 : 1;
        const bTypeR = getBooster(typeR);
        const bhornR = getBooster(hornR);
        const bcolorR = getBooster(colorR);
        const bglitterR = getBooster(glitterR);
        let score = 0.0325 * bTypeR * bhornR * bcolorR * bglitterR * firstEditionMul;
        score = (0, lodash_1.floor)(score, 4);
        return score;
    }
    return undefined;
};
exports.scoreForPolkamon = scoreForPolkamon;
const getBooster = (rarity) => {
    return 1 / rarity;
};
//# sourceMappingURL=rarityScoreChallenge.js.map