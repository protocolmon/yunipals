import { PolkamonMock } from './polkamonAttributes';
export declare const scoreForPolkamon: (polymon: PolkamonMock) => number | undefined;
