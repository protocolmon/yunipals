import { MonsterType } from '../../src/lib/type';
export declare const getTestCodes: ({ id, code, schema }: MonsterType) => Promise<string[]>;
