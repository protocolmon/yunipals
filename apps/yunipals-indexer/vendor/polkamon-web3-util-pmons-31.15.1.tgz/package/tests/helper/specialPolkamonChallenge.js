"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scoreForSpecialPolkamon = void 0;
const lodash_1 = require("lodash");
const babyTypes_1 = require("../../src/lib/type/babyTypes");
const polkamonAttributes_1 = require("./polkamonAttributes");
const capFrom = 1000000000000;
const capTo = 1900000000000;
const cap = 40000;
const MONSTER_NAMES_WITHOUT_RARITY = [
    'Colchian Unidragon',
    'Genesis Island Land Ticket',
    'Ukrainian Unidragon',
    'Ukrainian Unidonkey',
    'Rainbow Portal',
    ...babyTypes_1.BinanceBabyNames
];
const fixPointMonsterNames = {
    'Satoshi Babydragon': 40000
};
// copy of the staking challenge
const scoreForSpecialPolkamon = (polkamon) => {
    var _a;
    // exclude "Colchian Unidragon"
    const polymonType = (0, polkamonAttributes_1.getType)(polkamon);
    if (MONSTER_NAMES_WITHOUT_RARITY.includes(polymonType)) {
        return;
    }
    else if ((0, polkamonAttributes_1.isSpecial)(polkamon)) {
        const initialR = polkamon.initialProbabilities;
        const type = (0, polkamonAttributes_1.getType)(polkamon);
        const typeDef = (0, polkamonAttributes_1.getTypeDef)(type);
        const horn = (0, polkamonAttributes_1.getHorn)(polkamon);
        const hornDef = (0, polkamonAttributes_1.getHornDef)(horn);
        const glitter = (0, polkamonAttributes_1.isGlitter)(polkamon);
        const sound = (0, polkamonAttributes_1.getMemeSound)(polkamon);
        const soundDef = (0, polkamonAttributes_1.getMemeSoundsDef)(sound);
        const isBitcoinD = type === polkamonAttributes_1.types.bitcoinDragon.name || type === polkamonAttributes_1.types.bitcoinUnidragon.name;
        const typeR = isBitcoinD && (initialR === null || initialR === void 0 ? void 0 : initialR.type) === 0.001 ? 0.0001 : (initialR === null || initialR === void 0 ? void 0 : initialR.type) || (typeDef === null || typeDef === void 0 ? void 0 : typeDef.rarity) || 0.0002;
        // this is a small change to the orgin to allow permutaions in test cases. So babies may also be spceials
        const hornR = ((_a = (0, polkamonAttributes_1.getAdditionalHornDef)((0, polkamonAttributes_1.getHorn)(polkamon))) === null || _a === void 0 ? void 0 : _a.rarity) || (initialR === null || initialR === void 0 ? void 0 : initialR.horn) || (hornDef === null || hornDef === void 0 ? void 0 : hornDef.rarity) || 1;
        const glitterR = (initialR === null || initialR === void 0 ? void 0 : initialR.glitter) || (glitter ? polkamonAttributes_1.glitterRarity : polkamonAttributes_1.nonGlitterRarity);
        const soundR = (initialR === null || initialR === void 0 ? void 0 : initialR.sound) || (soundDef === null || soundDef === void 0 ? void 0 : soundDef.rarity) || 1;
        const firstEditionMul = (0, polkamonAttributes_1.getEdition)(polkamon) === 1 ? 1.2 : 1;
        const bitcoinMul = isBitcoinD ? 2 : 1;
        const bTypeR = getBooster(typeR);
        const bhornR = getBooster(hornR);
        const bglitterR = getBooster(glitterR);
        const bsoundR = getBooster(soundR);
        let score = 40 * bTypeR * bhornR * bglitterR * bsoundR * firstEditionMul * bitcoinMul;
        score = (0, lodash_1.floor)(score, 4);
        if (polkamon.id >= capFrom && polkamon.id < capTo && score > cap) {
            score = cap;
        }
        if (fixPointMonsterNames[polymonType]) {
            score = fixPointMonsterNames[polymonType];
        }
        return score;
    }
};
exports.scoreForSpecialPolkamon = scoreForSpecialPolkamon;
const getBooster = (rarity) => {
    return (1 / rarity - 1) / 8 + 1;
};
//# sourceMappingURL=specialPolkamonChallenge.js.map