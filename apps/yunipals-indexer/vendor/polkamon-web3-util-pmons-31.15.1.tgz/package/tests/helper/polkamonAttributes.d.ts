import { RareItem } from '../../src/lib/rarity';
import { InitialProbabilities } from '../../src/lib/rarity/types';
export declare const glitterRarity = 0.01;
export declare const nonGlitterRarity = 0.99;
export declare const types: {
    uniDonkey: {
        name: string;
        rarity: number;
    };
    uniFairy: {
        name: string;
        rarity: number;
    };
    uniAqua: {
        name: string;
        rarity: number;
    };
    uniTurtle: {
        name: string;
        rarity: number;
    };
    unikles: {
        name: string;
        rarity: number;
    };
    uniAir: {
        name: string;
        rarity: number;
    };
    uniChick: {
        name: string;
        rarity: number;
    };
    uniSheep: {
        name: string;
        rarity: number;
    };
    uniBranch: {
        name: string;
        rarity: number;
    };
    uniCursed: {
        name: string;
        rarity: number;
    };
    uniDragon: {
        name: string;
        rarity: number;
    };
    dancefloor: {
        name: string;
        rarity: number;
    };
    bitcoinUnidragon: {
        name: string;
        rarity: number;
    };
    bitcoinDragon: {
        name: string;
        rarity: number;
    };
    ethereumUnikles: {
        name: string;
        rarity: number;
    };
    moneroUnicursed: {
        name: string;
        rarity: number;
    };
    polkastarterBabydragon: {
        name: string;
        rarity: number;
    };
    moonrockMorningstarBabydragon: {
        name: string;
        rarity: number;
    };
    polkastarterEgg: {
        name: string;
        rarity: number;
    };
    moonrockMorningstarEgg: {
        name: string;
        rarity: number;
    };
    babyUnichick: {
        name: string;
        rarity: number;
    };
    babyUniAqua: {
        name: string;
        rarity: number;
    };
    babyUnibranch: {
        name: string;
        rarity: number;
    };
    babyUnifairy: {
        name: string;
        rarity: number;
    };
};
export declare function getTypeDef(type: string): {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
};
export declare const memeSounds: {
    hipHop: {
        name: string;
        rarity: number;
    };
    classic: {
        name: string;
        rarity: number;
    };
    rock: {
        name: string;
        rarity: number;
    };
    salsa: {
        name: string;
        rarity: number;
    };
    techno: {
        name: string;
        rarity: number;
    };
};
export declare function getMemeSoundsDef(memeSound: string): {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
} | {
    name: string;
    rarity: number;
};
export declare const colors: {
    purple: {
        name: string;
        rarity: number;
    };
    yellow: {
        name: string;
        rarity: number;
    };
    red: {
        name: string;
        rarity: number;
    };
    blue: {
        name: string;
        rarity: number;
    };
    green: {
        name: string;
        rarity: number;
    };
    black: {
        name: string;
        rarity: number;
    };
};
export declare const horns: {
    goldenHorn: {
        names: string[];
        rarity: number;
    };
    ivoryFang: {
        names: string[];
        rarity: number;
    };
    silverClaw: {
        names: string[];
        rarity: number;
    };
    diamondSpear: {
        names: string[];
        rarity: number;
    };
    shadowBranch: {
        names: string[];
        rarity: number;
    };
    spiralHorn: {
        names: string[];
        rarity: number;
    };
    dragonClaw: {
        names: string[];
        rarity: number;
    };
    candyCane: {
        names: string[];
        rarity: number;
    };
    wickedSpear: {
        names: string[];
        rarity: number;
    };
    silverEdge: {
        names: string[];
        rarity: number;
    };
};
export declare const additionalHorns: {
    babyHorn: {
        names: string[];
        rarity: number;
    };
};
export declare function getHornDef(horn: string): {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
} | {
    names: string[];
    rarity: number;
};
export declare function getAdditionalHornDef(horn: string): {
    names: string[];
    rarity: number;
};
export declare function getType(polkamon: any): any;
export declare function getHorn(polkamon: any): any;
export declare function getColor(polkamon: any): any;
export declare function isGlitter(polkamon: any): boolean;
export declare function isSpecial(polkamon: any): boolean;
export declare function isBinanceBaby(polkamon: any): boolean;
export declare function getEdition(polkamon: any): any;
export declare function getMemeSound(polkamon: any): any;
export declare function getBirthdate(polkamon: any): any;
export interface PolkamonMock {
    id?: number;
    attributes: Record<string, string | number>[];
    initialProbabilities: InitialProbabilities;
}
export declare const toPolkamonMock: (id: number, properties: Record<string, Record<string, any>>) => PolkamonMock;
export declare const toRareItem: (id: number, properties: Record<string, Record<string, any>>, originScore?: number) => RareItem;
