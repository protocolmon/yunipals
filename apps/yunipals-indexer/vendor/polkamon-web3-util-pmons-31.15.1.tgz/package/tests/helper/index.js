"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getScore = void 0;
const tslib_1 = require("tslib");
const rarityScoreChallenge_1 = require("./rarityScoreChallenge");
const specialPolkamonChallenge_1 = require("./specialPolkamonChallenge");
tslib_1.__exportStar(require("./polkamonAttributes"), exports);
tslib_1.__exportStar(require("./rarityScoreChallenge"), exports);
tslib_1.__exportStar(require("./specialPolkamonChallenge"), exports);
tslib_1.__exportStar(require("./assetCodeList"), exports);
const getScore = (polkamon) => {
    let score = (0, rarityScoreChallenge_1.scoreForPolkamon)(polkamon);
    if (!score) {
        score = (0, specialPolkamonChallenge_1.scoreForSpecialPolkamon)(polkamon);
    }
    return score;
};
exports.getScore = getScore;
//# sourceMappingURL=index.js.map