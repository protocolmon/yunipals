import { PolkamonMock } from './polkamonAttributes';
export * from './polkamonAttributes';
export * from './rarityScoreChallenge';
export * from './specialPolkamonChallenge';
export * from './assetCodeList';
export declare const getScore: (polkamon: PolkamonMock) => number | undefined;
