"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toRareItem = exports.toPolkamonMock = exports.getBirthdate = exports.getMemeSound = exports.getEdition = exports.isBinanceBaby = exports.isSpecial = exports.isGlitter = exports.getColor = exports.getHorn = exports.getType = exports.getAdditionalHornDef = exports.getHornDef = exports.additionalHorns = exports.horns = exports.colors = exports.getMemeSoundsDef = exports.memeSounds = exports.getTypeDef = exports.types = exports.nonGlitterRarity = exports.glitterRarity = void 0;
const tslib_1 = require("tslib");
const upperFirst_1 = tslib_1.__importDefault(require("lodash/upperFirst"));
const babyTypes_1 = require("../../src/lib/type/babyTypes");
const specialTypes_1 = require("../../src/lib/type/specialTypes");
const types_1 = require("../../src/lib/rarity/types");
exports.glitterRarity = 0.01;
exports.nonGlitterRarity = 0.99;
exports.types = {
    uniDonkey: { name: 'Unidonkey', rarity: 0.19 },
    uniFairy: { name: 'Unifairy', rarity: 0.15 },
    uniAqua: { name: 'Uniaqua', rarity: 0.01 },
    uniTurtle: { name: 'Uniturtle', rarity: 0.06 },
    unikles: { name: 'Unikles', rarity: 0.06 },
    uniAir: { name: 'Uniair', rarity: 0.06 },
    uniChick: { name: 'Unichick', rarity: 0.15 },
    uniSheep: { name: 'Unisheep', rarity: 0.1847 },
    uniBranch: { name: 'Unibranch', rarity: 0.03 },
    uniCursed: { name: 'Unicursed', rarity: 0.1 },
    uniDragon: { name: 'Unidragon', rarity: 0.005 },
    dancefloor: { name: 'The Dancefloor', rarity: 0.0033 },
    bitcoinUnidragon: { name: 'Bitcoin Unidragon', rarity: 0.0001 },
    bitcoinDragon: { name: 'Bitcoin Dragon', rarity: 0.0001 },
    ethereumUnikles: { name: 'Ethereum Unikles', rarity: 0.0001 },
    moneroUnicursed: { name: 'Monero Unicursed', rarity: 0.0001 },
    polkastarterBabydragon: { name: 'Polkastarter Babydragon', rarity: 0.0002 },
    moonrockMorningstarBabydragon: { name: 'Moonrock x Morningstar Babydragon', rarity: 0.0002 },
    polkastarterEgg: { name: 'Polkastarter Egg', rarity: 0.0002 },
    moonrockMorningstarEgg: { name: 'Moonrock x Morningstar Egg', rarity: 0.0002 },
    babyUnichick: { name: 'Baby Unichick', rarity: 0.015 },
    babyUniAqua: { name: 'Baby Uniaqua', rarity: 0.001 },
    babyUnibranch: { name: 'Baby Unibranch', rarity: 0.003 },
    babyUnifairy: { name: 'Baby Unifairy', rarity: 0.015 }
};
function getTypeDef(type) {
    return Object.values(exports.types).find((typeDef) => typeDef.name === type);
}
exports.getTypeDef = getTypeDef;
exports.memeSounds = {
    hipHop: { name: 'Hip-Hop', rarity: 0.35 },
    classic: { name: 'Classic', rarity: 0.3 },
    rock: { name: 'Rock', rarity: 0.2 },
    salsa: { name: 'Salsa', rarity: 0.1 },
    techno: { name: 'Techno', rarity: 0.05 }
};
function getMemeSoundsDef(memeSound) {
    return Object.values(exports.memeSounds).find((memeSoundsDef) => memeSoundsDef.name === memeSound);
}
exports.getMemeSoundsDef = getMemeSoundsDef;
exports.colors = {
    purple: { name: 'Purple', rarity: 0.05 },
    yellow: { name: 'Yellow', rarity: 0.15 },
    red: { name: 'Red', rarity: 0.2 },
    blue: { name: 'Blue', rarity: 0.25 },
    green: { name: 'Green', rarity: 0.345 },
    black: { name: 'Black', rarity: 0.0005 }
};
exports.horns = {
    goldenHorn: {
        names: ['Golden Horn', 'Wide'],
        rarity: 0.2
    },
    ivoryFang: {
        names: ['Ivory Fang', 'Ivory Curl'],
        rarity: 0.03
    },
    silverClaw: {
        names: ['Silver Claw'],
        rarity: 0.06
    },
    diamondSpear: {
        names: ['Diamond Spear', 'Diamond'],
        rarity: 0.01
    },
    shadowBranch: {
        names: ['Shadow Branch', 'Twisted Wood'],
        rarity: 0.05
    },
    spiralHorn: {
        names: ['Spiral Horn', 'Normal'],
        rarity: 0.2
    },
    dragonClaw: {
        names: ['Dragon Claw'],
        rarity: 0.06
    },
    candyCane: {
        names: ['Candy Cane'],
        rarity: 0.16
    },
    wickedSpear: {
        names: ['Wicked Spear', 'Spearhead'],
        rarity: 0.03
    },
    silverEdge: {
        names: ['Silver Edge', 'Silver Curved'],
        rarity: 0.2
    }
};
exports.additionalHorns = {
    babyHorn: {
        names: ['Baby Horn'],
        rarity: 0.2
    }
};
function getHornDef(horn) {
    return Object.values(exports.horns).find((hornDef) => hornDef.names.includes(horn));
}
exports.getHornDef = getHornDef;
function getAdditionalHornDef(horn) {
    return Object.values(exports.additionalHorns).find((hornDef) => hornDef.names.includes(horn));
}
exports.getAdditionalHornDef = getAdditionalHornDef;
function getType(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.type);
}
exports.getType = getType;
function getHorn(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.horn);
}
exports.getHorn = getHorn;
function getColor(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.color);
}
exports.getColor = getColor;
function isGlitter(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.glitter) === 'Yes';
}
exports.isGlitter = isGlitter;
function isSpecial(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.special) === 'Yes';
}
exports.isSpecial = isSpecial;
function isBinanceBaby(polkamon) {
    return babyTypes_1.BinanceBabyNames.includes(getAttributeValue(polkamon.attributes, traitTypes.type));
}
exports.isBinanceBaby = isBinanceBaby;
function getEdition(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.edition);
}
exports.getEdition = getEdition;
function getMemeSound(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.memeSound);
}
exports.getMemeSound = getMemeSound;
function getBirthdate(polkamon) {
    return getAttributeValue(polkamon.attributes, traitTypes.birthdate);
}
exports.getBirthdate = getBirthdate;
const traitTypes = {
    type: 'Type',
    horn: 'Horn',
    color: 'Color',
    glitter: 'Glitter',
    special: 'Special',
    edition: 'Edition',
    firstEdition: 'First Edition',
    memeSound: 'Sound',
    birthdate: 'Birthday'
};
function getAttributeValue(attributes, traitType) {
    const attribute = attributes.find((attribute) => attribute.trait_type === traitType);
    if (attribute) {
        return attribute.value;
    }
    else {
        return undefined;
    }
}
// the building is a bit hacky because of the input that is generated by a generic product function.
// but for tests ok
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const toPolkamonMock = (id, properties) => {
    const isSpecial = (0, specialTypes_1.isSpecialId)(Object.keys(properties.type)[0]);
    const edition = Object.values(properties.edition)[0];
    const attributes = Object.entries(properties)
        .filter(([key]) => !['special', 'edition'].includes(key))
        .reduce((attrs, [key, value]) => [
        ...attrs,
        {
            value: Object.values(value)[0].name,
            trait_type: (0, upperFirst_1.default)(key)
        }
    ], [
        { value: isSpecial ? 'Yes' : 'No', trait_type: 'Special' },
        { value: Number.parseInt(edition.name), trait_type: 'Edition' } // the old calculation expects a number as it does 1 === edition.value
    ]);
    const initialProbabilities = Object.entries(properties)
        .filter(([key]) => types_1.ProbabilityNames.includes(key))
        .reduce((attrs, [key, value]) => ({
        ...attrs,
        [key]: Object.values(value)[0].initialRarity
    }), {});
    return {
        id,
        attributes,
        initialProbabilities
    };
};
exports.toPolkamonMock = toPolkamonMock;
const toRareItem = (id, 
// eslint-disable-next-line @typescript-eslint/no-explicit-any
properties, originScore) => {
    const isSpecial = (0, specialTypes_1.isSpecialId)(Object.keys(properties.type)[0]);
    const attributes = Object.entries(properties).reduce((attrs, [key, value]) => ({
        ...attrs,
        [key]: {
            value: Object.values(value)[0].name,
            type: (0, upperFirst_1.default)(key)
        }
    }), { special: { value: isSpecial ? 'Yes' : 'No', type: 'Special' } });
    const initialProbabilities = Object.entries(properties)
        .filter(([key]) => types_1.ProbabilityNames.includes(key))
        .reduce((attrs, [key, value]) => ({
        ...attrs,
        [key]: Object.values(value)[0].initialRarity
    }), {});
    return {
        id: id.toString(),
        attributes,
        initialProbabilities,
        originScore
    };
};
exports.toRareItem = toRareItem;
//# sourceMappingURL=polkamonAttributes.js.map