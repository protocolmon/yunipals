export type MonsterType = [string, number, string, string, string, string?, string?];
export interface Polymon {
    type: string;
    horn: string;
    color: string;
    background: string;
    glitter: string;
    special: string;
    memeSound?: string;
}
export type OpeningSpecialsCollection = Array<{
    name: string;
    data: MonsterType | [];
    amount: number;
}>;
export type PolymonGenerationParams = <T = unknown>(polymon: Polymon, additionalTypes: Array<MonsterType>) => T;
