"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTypeNameOfPolkamon = exports.getTypeDescriptionOfPolkamon = exports.getPropertyNamesOfPolkamon = exports.getInitialProbabilitiesOfPolkamon = exports.getPropertyIdsOfPolkamon = exports.glitters = exports.backgrounds = exports.colors = exports.specialTypes = exports.basicTypes = exports.horns = void 0;
// format : [internal id, probability, name, external id]
exports.horns = [
    ['1', 0.2, 'Golden Horn', '01'],
    ['2', 0.03, 'Ivory Fang', '02'],
    ['3', 0.06, 'Silver Claw', '03'],
    ['4', 0.01, 'Diamond Spear', '04'],
    ['5', 0.05, 'Shadow Branch', '05'],
    ['6', 0.2, 'Spiral Horn', '06'],
    ['7', 0.06, 'Dragon Claw', '07'],
    ['8', 0.16, 'Candy Cane', '08'],
    ['9', 0.03, 'Wicked Spear', '09'],
    ['10', 0.2, 'Silver Edge', '10']
];
// format : [internal id, probability, name, external id, description, [special] ]
// special : [ name, external id, description ]
exports.basicTypes = [
    [
        'unitiger',
        0.06,
        'Unitiger',
        '258',
        'Built to challenge even the mightiest of heroes, the Unitiger preys on the weak, overwhelming its competition with tremendous speed and power. Few have lived to tell of a bout with the Unitiger, and fewer yet have experienced victory.'
    ],
    [
        'unigiraffe',
        0.155,
        'Unigiraffe',
        '259',
        "The Unigiraffe is a big fan of Web3. With its long neck, the Unigiraffe is able to reach the best liquidity pools, trade effortlessly above exorbitant gas fees, and get a bird's eye view of the battlefield in many blockchain games."
    ],
    [
        'unioctopus',
        0.155,
        'Unioctopus',
        '265',
        'Residing in the deep dark depths of the waters below, the Unioctopus navigates the sea floor with its eight powerful tentacles. It is fiercely territorial, and will recklessly defend its homes from all foreign invaders.'
    ],
    [
        'unipanda',
        0.06,
        'Unipanda',
        '267',
        'Having been sent from future, the Unipanda shares its knowledge and seamlessly provides an answer to the blockchain trilemma. A brand new flexible sharding solution is available to all who follow in its wisdom.'
    ],
    [
        'unizilla',
        0.04,
        'Unizilla',
        '269',
        'After tearing down multiple cities, the Unizilla has made its way towards the rest of the Polyverse, continuing its rampage of complete destruction. Watch out or you might be next!'
    ],
    [
        'uniphoenix',
        0.235,
        'Uniphoenix',
        '278',
        'Continually and perpetually reborn of great fire, the Uniphoenix symbolizes freedom from the end and a fresh start again. Legend says that they can freely travel between various realms of different existences.'
    ],
    [
        'unishiba',
        0.235,
        'Unishiba',
        '280',
        'Such adorable, much wow! The Unishiba has returned from space and has set its sights on exploring the vast mysteries of the Polyverse instead. The moon was nice, but the universe is better.'
    ],
    [
        'unibull',
        0.06,
        'Unibull',
        '257',
        'Said to be the great protector of markets, the Unibull stands dilligently by fair trade and earnest gains. Folk lore attributes its mere presence to that of wealth and good fortune, and thus it is considered quite lucky to encounter one.'
    ]
];
exports.specialTypes = [];
// format : [internal id, probability, name, external id]
exports.colors = [
    ['purple', 0.05, 'Purple', '04'],
    ['yellow', 0.15, 'Yellow', '01'],
    ['red', 0.2, 'Red', '05'],
    ['blue', 0.25, 'Blue', '03'],
    ['green', 0.3457, 'Green', '02'],
    ['black', 0.0005, 'Black', '06'],
    ['rosegold', 0.0022, 'Rose Gold', '07'],
    ['whitegold', 0.0012, 'White Gold', '08'],
    ['gold', 0.0004, 'Pure Gold', '09']
];
// format : [internal id, probability, name, external id]
exports.backgrounds = [
    ['winterWonderland', 0.9333, 'Winter Wonderland', '61'],
    ['winterWonderlandSanta', 0.0667, 'Winter Wonderland Santa', '92']
];
// format : [internal id, probability, name, external id]
exports.glitters = [
    ['glitter', 0.01, 'Yes', '01'],
    ['noGlitter', 0.99, 'No', '00']
];
const getPropertyIdsOfPolkamon = (polymon, additionalTypes) => {
    const allAvailableTypes = [...exports.basicTypes, ...additionalTypes];
    const properties = {
        horn: exports.horns[Number(polymon.horn) - 1][3],
        color: exports.colors[Number(polymon.color) - 1][3],
        background: exports.backgrounds[Number(polymon.background) - 1][3],
        glitter: exports.glitters[Number(polymon.glitter) - 1][3],
        type: allAvailableTypes[Number(polymon.type) - 1][3],
        memeSound: undefined
    };
    return properties;
};
exports.getPropertyIdsOfPolkamon = getPropertyIdsOfPolkamon;
const getInitialProbabilitiesOfPolkamon = (polymon, additionalTypes) => {
    const allAvailableTypes = [...exports.basicTypes, ...additionalTypes];
    const initialProbabilities = {
        horn: exports.horns[Number(polymon.horn) - 1][1],
        color: exports.colors[Number(polymon.color) - 1][1],
        background: exports.backgrounds[Number(polymon.background) - 1][1],
        glitter: exports.glitters[Number(polymon.glitter) - 1][1],
        type: allAvailableTypes[Number(polymon.type) - 1][1]
    };
    return initialProbabilities;
};
exports.getInitialProbabilitiesOfPolkamon = getInitialProbabilitiesOfPolkamon;
const getPropertyNamesOfPolkamon = (polymon, additionalTypes) => {
    const allAvailableTypes = [...exports.basicTypes, ...additionalTypes];
    const properties = {
        horn: exports.horns[Number(polymon.horn) - 1][2],
        color: exports.colors[Number(polymon.color) - 1][2],
        background: exports.backgrounds[Number(polymon.background) - 1][2],
        glitter: exports.glitters[Number(polymon.glitter) - 1][2],
        type: allAvailableTypes[Number(polymon.type) - 1][2],
        special: 'No',
        memeSound: undefined
    };
    return properties;
};
exports.getPropertyNamesOfPolkamon = getPropertyNamesOfPolkamon;
const getTypeDescriptionOfPolkamon = (polymon, additionalTypes) => {
    const description = [...exports.basicTypes, ...additionalTypes][Number(polymon.type) - 1][4];
    return description;
};
exports.getTypeDescriptionOfPolkamon = getTypeDescriptionOfPolkamon;
const getTypeNameOfPolkamon = (polymon, additionalTypes) => {
    const name = [...exports.basicTypes, ...additionalTypes][Number(polymon.type) - 1][2];
    return name;
};
exports.getTypeNameOfPolkamon = getTypeNameOfPolkamon;
//# sourceMappingURL=polkamonData.js.map