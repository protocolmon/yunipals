import { MonsterType, Polymon } from '../types';
export declare const horns: [string, number, string, string][];
export declare const basicTypes: Array<MonsterType>;
export declare const specialTypes: Array<MonsterType>;
export declare const colors: [string, number, string, string][];
export declare const backgrounds: [string, number, string, string][];
export declare const glitters: [string, number, string, string][];
export declare const getPropertyIdsOfPolkamon: (polymon: Polymon, additionalTypes: Array<MonsterType>) => {
    horn: string;
    color: string;
    background: string;
    glitter: string;
    type: string;
    memeSound: any;
};
export declare const getInitialProbabilitiesOfPolkamon: (polymon: Polymon, additionalTypes: Array<MonsterType>) => {
    horn: number;
    color: number;
    background: number;
    glitter: number;
    type: number;
};
export declare const getPropertyNamesOfPolkamon: (polymon: Polymon, additionalTypes: Array<MonsterType>) => {
    horn: string;
    color: string;
    background: string;
    glitter: string;
    type: string;
    special: string;
    memeSound: any;
};
export declare const getTypeDescriptionOfPolkamon: (polymon: Polymon, additionalTypes: Array<MonsterType>) => string;
export declare const getTypeNameOfPolkamon: (polymon: Polymon, additionalTypes: Array<MonsterType>) => string;
