"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPolkamonFromRandomNumber = void 0;
const polkamonData_1 = require("./polkamonData");
const bytes_1 = require("@ethersproject/bytes");
const bignumber_1 = require("@ethersproject/bignumber");
const polkamonsPerBooster = 3;
const requiredBytesPerPolkamon = 9;
const getPolkamonFromRandomNumber = ({ randomHex32Byte, additionalTypes = [] }) => {
    // Per to-be-pulled polkamon in a booster pack we need a array with random integers
    // Each random number is used to determine one of the properties of the polkamon (e.g. the type of horn)
    // We get the array of random numbers by building a byteArray from the Hex32Byte string
    // We use one random Hex32Byte string per pack opening, so we need multiple arrays with random integers
    const byteArrays = getByteArrays(randomHex32Byte, false);
    const byteArraysAsHex = getByteArrays(randomHex32Byte, true);
    // Per byteArray we determine the 5 properties per polkamon
    const polkamons = [];
    for (const [i, byteArray] of byteArrays.entries()) {
        const type = getProperty({
            probabilities: [...polkamonData_1.basicTypes, ...additionalTypes].map((el) => el[1]),
            randomNumber: bignumber_1.BigNumber.from(('0x' + (byteArraysAsHex[i][0] + byteArraysAsHex[i][7]))).toNumber(),
            bytesPerNumber: 2
        });
        const horn = getProperty({
            probabilities: polkamonData_1.horns.map((el) => el[1]),
            randomNumber: byteArray[1],
            bytesPerNumber: 1
        });
        const color = getProperty({
            probabilities: polkamonData_1.colors.map((el) => el[1]),
            randomNumber: bignumber_1.BigNumber.from(('0x' + (byteArraysAsHex[i][2] + byteArraysAsHex[i][8]))).toNumber(),
            bytesPerNumber: 2
        });
        const background = getProperty({
            probabilities: polkamonData_1.backgrounds.map((el) => el[1]),
            randomNumber: byteArray[3],
            bytesPerNumber: 1
        });
        const glitter = getProperty({
            probabilities: polkamonData_1.glitters.map((el) => el[1]),
            randomNumber: byteArray[4],
            bytesPerNumber: 1
        });
        polkamons.push({
            type,
            horn,
            color,
            background,
            glitter
        });
    }
    return polkamons;
};
exports.getPolkamonFromRandomNumber = getPolkamonFromRandomNumber;
const getByteArrays = (randomHex32Byte, asHex) => {
    var _a;
    const arrayOfByteArrays = [];
    for (let i = 0; i < polkamonsPerBooster; i++) {
        if (!asHex) {
            arrayOfByteArrays.push((0, bytes_1.arrayify)(randomHex32Byte).slice(requiredBytesPerPolkamon * i, requiredBytesPerPolkamon * (1 + i)));
        }
        else {
            const hexStringWithoutPrefix = (0, bytes_1.hexlify)(randomHex32Byte);
            arrayOfByteArrays.push((_a = hexStringWithoutPrefix
                .slice(requiredBytesPerPolkamon * i * 2, requiredBytesPerPolkamon * (i + 1) * 2)
                .match(/.{1,2}/g)) !== null && _a !== void 0 ? _a : '');
        }
    }
    return arrayOfByteArrays;
};
const getNormalizedProbability = ({ randomNumber, probablitySum, maxNumber }) => {
    return (randomNumber / maxNumber) * probablitySum;
};
const getCumulatedProbabilities = (probabilitiesArray) => {
    const probabilitiesArray_cumulated = [];
    probabilitiesArray.reduce(function (a, b, i) {
        return (probabilitiesArray_cumulated[i] = a + b);
    }, 0);
    return probabilitiesArray_cumulated;
};
const getProperty = ({ probabilities, randomNumber, bytesPerNumber = 1 }) => {
    const probabilities_cumulated = getCumulatedProbabilities(probabilities);
    const probablitySum = probabilities_cumulated[probabilities_cumulated.length - 1];
    const normalizedRandomNumber = getNormalizedProbability({
        randomNumber,
        probablitySum,
        maxNumber: Math.pow(2, bytesPerNumber * 8)
    });
    for (const [i, probability_cumulated] of probabilities_cumulated.entries()) {
        if (normalizedRandomNumber <= probability_cumulated) {
            return i + 1;
        }
    }
};
//# sourceMappingURL=getPolkamonFromRandomNumber.js.map