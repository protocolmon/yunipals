"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTypeNameOfPolkamon = exports.getTypeDescriptionOfPolkamon = exports.getPropertyNamesOfPolkamon = exports.getInitialProbabilitiesOfPolkamon = exports.getPropertyIdsOfPolkamon = exports.glitters = exports.backgrounds = exports.colors = exports.specialTypes = exports.basicTypes = exports.horns = void 0;
// format : [internal id, probability, name, external id]
exports.horns = [
    ['1', 0.2, 'Golden Horn', '01'],
    ['2', 0.03, 'Ivory Fang', '02'],
    ['3', 0.06, 'Silver Claw', '03'],
    ['4', 0.01, 'Diamond Spear', '04'],
    ['5', 0.05, 'Shadow Branch', '05'],
    ['6', 0.2, 'Spiral Horn', '06'],
    ['7', 0.06, 'Dragon Claw', '07'],
    ['8', 0.16, 'Candy Cane', '08'],
    ['9', 0.03, 'Wicked Spear', '09'],
    ['10', 0.2, 'Silver Edge', '10']
];
// format : [internal id, probability, name, external id, description, [special] ]
// special : [ name, external id, description ]
exports.basicTypes = [
    [
        'uniDonkey',
        0.19,
        'Unidonkey',
        '01',
        'The Unidonkey is quite skittish and reserved, but there is much power in their potential. Adored by even the smallest of hearts, its canter gives a calm rhythm to all eyes and ears.'
    ],
    [
        'uniFairy',
        0.15,
        'Unifairy',
        '02',
        'The Unifairy is the most magical and fairest Polychain Monster. Their wings stretch into the realms beyond this world, enchanting those around them by their unique disposition.'
    ],
    [
        'uniAqua',
        0.01,
        'Uniaqua',
        '03',
        'From raging seas to sunset landscapes, the Uniaqua is fit for all terrains. Where other Polychain Monsters glory in their uniqueness, the Uniaqua takes its prestige in versatility.'
    ],
    [
        'uniTurtle',
        0.06,
        'Uniturtle',
        '04',
        'Recognized from afar by its special movements, the Uniturtle glides across terrain with ease. They also have maximum eyesight for their surroundings with their snug-fitting goggles.'
    ],
    [
        'unikles',
        0.06,
        'Unikles',
        '05',
        'The Unikles is a Polychain Monster that radiates the characteristics of grandeur and excellence. Recognized well by its salient mane, Unikles maintains confidence and assertiveness in all situations.'
    ],
    [
        'uniAir',
        0.06,
        'Uniair',
        '06',
        'One with the calm, the Uniair is a species that enjoys the tranquillity of elevation. A true underdog, the Uniair gives an endearing presence with every move.'
    ],
    [
        'uniChick',
        0.15,
        'Unichick',
        '07',
        'Hectic and fluttering, the Unichick is always on the move, discovering life at the fastest pace. Behind the hyperactive facade is the full presence of timidity and thoughtfulness.'
    ],
    [
        'uniSheep',
        0.185,
        'Unisheep',
        '08',
        'Mindful of a million things, the Unisheep is a Polychain Monster that can graze and gander the day away. Creating an environment to direct these creatures actively helps them focus on one particular topic.'
    ],
    [
        'uniBranch',
        0.03,
        'Unibranch',
        '09',
        'The Unibranch embodies the art of elegance and grace. Gathering and attracting large crowds, Unibranch manifest scene of delight and charm.'
    ],
    [
        'uniCursed',
        0.1,
        'Unicursed',
        '10',
        'Among all Polychain Monsters is the reserved and reticent Unicursed, always present but never there. Using the attributes of invisibility, Unicursed keep to their own, hiding in plain sight.'
    ],
    [
        'uniDragon',
        0.005,
        'Unidragon',
        '11',
        'Adorning both glimmer and self-confidence, the Unidragon is stalwart and courageous. None stands above such a character except for the Bitcoin Unidragon.'
    ]
];
exports.specialTypes = [];
// format : [internal id, probability, name, external id]
exports.colors = [['ghost', 1, 'Ghost', '94']];
// format : [internal id, probability, name, external id]
exports.backgrounds = [['ghostLand', 1, 'Ghost Grassland', '08']];
// format : [internal id, probability, name, external id]
exports.glitters = [
    ['glitter', 0.01, 'Yes', '01'],
    ['noGlitter', 0.99, 'No', '00']
];
const getPropertyIdsOfPolkamon = (polymon, additionalTypes) => {
    const allAvailableTypes = [...exports.basicTypes, ...additionalTypes];
    const properties = {
        horn: exports.horns[Number(polymon.horn) - 1][3],
        color: exports.colors[Number(polymon.color) - 1][3],
        background: exports.backgrounds[Number(polymon.background) - 1][3],
        glitter: exports.glitters[Number(polymon.glitter) - 1][3],
        type: allAvailableTypes[Number(polymon.type) - 1][3],
        memeSound: undefined
    };
    return properties;
};
exports.getPropertyIdsOfPolkamon = getPropertyIdsOfPolkamon;
const getInitialProbabilitiesOfPolkamon = (polymon, additionalTypes) => {
    const allAvailableTypes = [...exports.basicTypes, ...additionalTypes];
    const initialProbabilities = {
        horn: exports.horns[Number(polymon.horn) - 1][1],
        color: exports.colors[Number(polymon.color) - 1][1],
        background: exports.backgrounds[Number(polymon.background) - 1][1],
        glitter: exports.glitters[Number(polymon.glitter) - 1][1],
        type: allAvailableTypes[Number(polymon.type) - 1][1]
    };
    return initialProbabilities;
};
exports.getInitialProbabilitiesOfPolkamon = getInitialProbabilitiesOfPolkamon;
const getPropertyNamesOfPolkamon = (polymon, additionalTypes) => {
    const allAvailableTypes = [...exports.basicTypes, ...additionalTypes];
    const properties = {
        horn: exports.horns[Number(polymon.horn) - 1][2],
        color: exports.colors[Number(polymon.color) - 1][2],
        background: exports.backgrounds[Number(polymon.background) - 1][2],
        glitter: exports.glitters[Number(polymon.glitter) - 1][2],
        type: allAvailableTypes[Number(polymon.type) - 1][2],
        special: 'No',
        memeSound: undefined
    };
    return properties;
};
exports.getPropertyNamesOfPolkamon = getPropertyNamesOfPolkamon;
const getTypeDescriptionOfPolkamon = (polymon, additionalTypes) => {
    const description = [...exports.basicTypes, ...additionalTypes][Number(polymon.type) - 1][4];
    return description;
};
exports.getTypeDescriptionOfPolkamon = getTypeDescriptionOfPolkamon;
const getTypeNameOfPolkamon = (polymon, additionalTypes) => {
    const name = [...exports.basicTypes, ...additionalTypes][Number(polymon.type) - 1][2];
    return name;
};
exports.getTypeNameOfPolkamon = getTypeNameOfPolkamon;
//# sourceMappingURL=polkamonData.js.map