import { MonsterType, Polymon } from '../types';
export declare const getPolkamonFromRandomNumber: ({ randomHex32Byte, additionalTypes }: {
    additionalTypes: Array<MonsterType>;
    randomHex32Byte: string;
}) => Polymon[];
