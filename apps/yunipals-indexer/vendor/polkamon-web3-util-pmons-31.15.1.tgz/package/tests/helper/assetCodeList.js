"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTestCodes = void 0;
const promises_1 = require("fs/promises");
const attributes_1 = require("../../src/lib/attributes");
const lodash_1 = require("lodash");
const path_1 = require("path");
let codesByType = {};
const getTestCodes = async ({ id, code, schema }) => {
    const searchRegEx = generateRegexForType(code, schema);
    const content = await (0, promises_1.readFile)(__dirname + '/assetCodesFromGit.txt', 'utf-8');
    if (!(codesByType === null || codesByType === void 0 ? void 0 : codesByType[id]))
        codesByType = content.split(/\r?\n/).reduce((result, line) => {
            var _a;
            const code = (_a = (0, path_1.parse)(line).name) === null || _a === void 0 ? void 0 : _a.replace('Unimons_', '');
            const matches = code.match(searchRegEx);
            return matches ? { ...result, [id]: [...(result[id] || []), code] } : result;
        }, codesByType);
    return (codesByType === null || codesByType === void 0 ? void 0 : codesByType[id]) || [];
};
exports.getTestCodes = getTestCodes;
const attrRegex = (src, base) => (src || []).map((searchId) => { var _a; return (_a = (0, lodash_1.values)(base).find(({ id }) => id == searchId)) === null || _a === void 0 ? void 0 : _a.code; }).join('|');
const generateRegexForType = (code, schema) => {
    var _a, _b, _c, _d;
    // only the color is relavant here because we must distinquish bestimmt rainbow and not rainbow
    const colorCodes = attrRegex(schema.color, attributes_1.Colors);
    const hornCodes = attrRegex(schema.horn, attributes_1.Horns);
    const bgCodes = attrRegex(schema.background, attributes_1.Backgrounds);
    const glitterCodes = attrRegex(schema.glitter, attributes_1.Glitters);
    let suffix = '';
    if (((_a = schema.variant) === null || _a === void 0 ? void 0 : _a.length) > 0) {
        suffix = '(' + attrRegex(schema.variant, attributes_1.Variants) + ')';
    }
    if (((_b = schema.sound) === null || _b === void 0 ? void 0 : _b.length) > 0) {
        suffix = '(' + attrRegex(schema.sound, attributes_1.Sounds) + ')';
    }
    if (((_c = schema.amount) === null || _c === void 0 ? void 0 : _c.length) > 0) {
        suffix += '(' + attrRegex(schema.amount, attributes_1.Amounts) + ')';
    }
    if (((_d = schema.time) === null || _d === void 0 ? void 0 : _d.length) > 0) {
        suffix += '(' + attrRegex(schema.time, attributes_1.Times) + ')';
    }
    const regExStr = [`^${code}(${colorCodes})(${hornCodes})(${bgCodes})(${glitterCodes})`];
    if (suffix) {
        regExStr.push(`(_${suffix})`);
    }
    regExStr.push('$');
    return new RegExp(regExStr.join(''), 'i');
};
//# sourceMappingURL=assetCodeList.js.map