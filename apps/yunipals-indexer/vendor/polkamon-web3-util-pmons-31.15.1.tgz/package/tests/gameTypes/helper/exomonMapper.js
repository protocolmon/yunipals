"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.exomonMapper = void 0;
const lodash_1 = require("lodash");
const src_1 = require("../../../src");
const utils_1 = require("./utils");
const exomonMapper = (input) => {
    const name = input['Exomon'];
    const type = (0, lodash_1.find)(src_1.Types, { id: (0, lodash_1.camelCase)(name) });
    return (0, utils_1.createTestData)(type, input['Color'], input);
};
exports.exomonMapper = exomonMapper;
//# sourceMappingURL=exomonMapper.js.map