import { MonsterType } from '../../../src/lib';
import { BaseTestData, ReadDataConfig, TestData } from '.';
export declare const createTestData: (type: MonsterType, color: string, input: unknown) => BaseTestData | undefined;
export declare const readTestData: ({ group, from, to }: ReadDataConfig) => (TestData | undefined)[];
