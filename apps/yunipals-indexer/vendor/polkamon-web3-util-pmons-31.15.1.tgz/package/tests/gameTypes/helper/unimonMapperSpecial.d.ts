import { BaseTestData } from './types';
export declare const unimonSpecialMapper: (input: unknown) => BaseTestData | undefined;
