import { BaseTestData } from './types';
export declare const unimonMapper: (input: unknown) => BaseTestData | undefined;
