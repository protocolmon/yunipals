import { MonsterType, Playabale, PmonAttributes } from '../../../src/lib';
export interface TestData extends Playabale {
    type: MonsterType;
    attributes: PmonAttributes;
    code: string;
}
export type BaseTestData = Omit<TestData, 'code'>;
export type Mapper = (input: unknown) => BaseTestData;
export type TestGroup = 'unimon' | 'unimonSpecial' | 'exomon' | 'exomonSpecial';
export interface ReadDataConfig {
    group: TestGroup;
    from?: number;
    to?: number;
}
