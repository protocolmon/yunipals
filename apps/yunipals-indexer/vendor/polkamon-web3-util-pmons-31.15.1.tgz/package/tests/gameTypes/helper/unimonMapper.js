"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unimonMapper = void 0;
const lodash_1 = require("lodash");
const src_1 = require("../../../src");
const utils_1 = require("./utils");
const unimonMapper = (input) => {
    let typeName = input['Unimon'];
    if (input['Fusion'].toLowerCase().includes('rainbow')) {
        typeName = `Rainbow ${input['Unimon']}`;
    }
    else if (input['Ghost'].toLowerCase().includes('yes')) {
        typeName = `Ghost ${input['Unimon']}`;
    }
    else if (input['Baby'].toLowerCase().includes('yes')) {
        typeName = `Baby ${input['Unimon']}`;
    }
    else if (input['Crystal'].toLowerCase().includes('yes')) {
        typeName = `Crystal ${input['Unimon']}`;
    }
    const color = input['Color'];
    if (input['Baby'].toLowerCase().includes('yes') && src_1.ExtraColorNames.includes(color)) {
        return undefined;
    }
    // BNB special case
    if (src_1.BinanceBabyNames.includes(typeName)) {
        // first edition is not supported for these babies
        if (input['1stEdition'].toLowerCase().includes('yes')) {
            return undefined;
        }
        // these only work with glitter otherwise not supported
        if (['Black', 'Purple'].includes(color) && !input['Glitter'].toLowerCase().includes('glitter')) {
            return undefined;
        }
        // same for the other way round
        if (!['Black', 'Purple'].includes(color) && input['Glitter'].toLowerCase().includes('glitter')) {
            return undefined;
        }
    }
    const type = (0, lodash_1.find)(src_1.Types, { name: typeName });
    return (0, utils_1.createTestData)(type, color, input);
};
exports.unimonMapper = unimonMapper;
//# sourceMappingURL=unimonMapper.js.map