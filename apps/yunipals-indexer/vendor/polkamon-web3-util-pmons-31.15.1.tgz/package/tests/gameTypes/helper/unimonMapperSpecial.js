"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unimonSpecialMapper = void 0;
const lodash_1 = require("lodash");
const src_1 = require("../../../src");
const utils_1 = require("./utils");
const unimonSpecialMapper = (input) => {
    let name = input['Unimon'];
    const color = input['Color'];
    let id;
    // strip color infos wrong test data
    if (name.includes('Binance Baby Unidragon')) {
        id = 'binanceBabyUnidragonSpecial';
        input['Variant'] = 'Binance Fire';
        if (name.includes('Purple Fire')) {
            id = 'binanceBabyUnidragonPurple';
            input['Variant'] = 'Purple Fire';
        }
        else if (name.includes('Yellow Fire')) {
            id = 'binanceBabyUnidragonYellow';
            input['Variant'] = 'Yellow Fire';
        }
        else if (name.includes('Red Fire')) {
            id = 'binanceBabyUnidragonRed';
            input['Variant'] = 'Red Fire';
        }
        else if (name.includes('Blue Fire')) {
            id = 'binanceBabyUnidragonBlue';
            input['Variant'] = 'Blue Fire';
        }
        else if (name.includes('Green Fire')) {
            id = 'binanceBabyUnidragonGreen';
            input['Variant'] = 'Green Fire';
        }
        name = 'Binance Baby Unidragon';
    }
    if (name.includes('Christmas Unibranch') && input['Horn'].toLowerCase().includes('diamond antlers')) {
        id = `christmasUnibranchDiamond`;
        if (input['Glitter'].toLowerCase().includes('glitter')) {
            id = `christmasUnibranchPencilsOfPromise`;
        }
    }
    if (name === 'Colchian Unidragon' && !input['Glitter'].toLowerCase().includes('glitter')) {
        return undefined;
    }
    const type = (0, lodash_1.find)(src_1.Types, id ? { id } : { name });
    return (0, utils_1.createTestData)(type, color, input);
};
exports.unimonSpecialMapper = unimonSpecialMapper;
//# sourceMappingURL=unimonMapperSpecial.js.map