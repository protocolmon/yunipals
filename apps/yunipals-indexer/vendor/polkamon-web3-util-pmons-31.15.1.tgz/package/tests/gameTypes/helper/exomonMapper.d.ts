import { BaseTestData } from './types';
export declare const exomonMapper: (input: unknown) => BaseTestData | undefined;
