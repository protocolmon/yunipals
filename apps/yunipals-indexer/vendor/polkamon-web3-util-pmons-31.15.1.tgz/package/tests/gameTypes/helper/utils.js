"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readTestData = exports.createTestData = void 0;
const tslib_1 = require("tslib");
const util_essentials_1 = require("@polkamon/util-essentials");
const convert_csv_to_json_1 = tslib_1.__importDefault(require("convert-csv-to-json"));
const lodash_1 = require("lodash");
const path_1 = require("path");
const lib_1 = require("../../../src/lib");
const _1 = require(".");
const createTestData = (type, color, input) => ({
    type,
    attributes: {
        type: { value: type.name },
        horn: { value: input['Horn'] },
        glitter: { value: input['Glitter'] },
        color: { value: color },
        ...(input['1stEdition'] ? { firstEdition: { value: input['1stEdition'] } } : {}),
        ...(input['Special'] ? { special: { value: input['Special'] } } : {}),
        ...(input['Celestial'] ? { celestial: { value: input['Celestial'] } } : {}),
        ...(input['Variant'] ? { variant: { value: input['Variant'] } } : {})
    },
    gameData: {
        version: 'v4',
        pFactor: (0, util_essentials_1.toFloat)(input['P-Factor'], 0),
        score: (0, util_essentials_1.toFloat)(input['BattleScore'], 0),
        health: (0, util_essentials_1.toInt)(input['HP'], 0),
        water: (0, util_essentials_1.toInt)(input['Water'], 0),
        fire: (0, util_essentials_1.toInt)(input['Fire'], 0),
        earth: (0, util_essentials_1.toInt)(input['Earth'], 0),
        wind: (0, util_essentials_1.toInt)(input['Wind'], 0),
        sum: (0, util_essentials_1.toInt)(input['Sum'], 0)
    }
});
exports.createTestData = createTestData;
const mapper = () => ({
    unimon: _1.unimonMapper,
    unimonSpecial: _1.unimonSpecialMapper,
    exomon: _1.exomonMapper,
    exomonSpecial: _1.exomonMapper
});
const readTestData = ({ group, from, to }) => {
    const json = (0, lodash_1.slice)(convert_csv_to_json_1.default.fieldDelimiter(',').getJsonFromCsv((0, path_1.join)(__dirname, `../${group}.csv`)), from, (0, lodash_1.isNumber)(to) ? to : (0, lodash_1.isNumber)(from) ? from + 1 : undefined);
    return (0, lodash_1.reduce)(json, (list, src) => {
        const base = mapper()[group](src);
        if (!base) {
            return [...list, undefined];
        }
        const type = base.type;
        // in the source table we have no backgrounds as they are ignored for the game
        // so we use the first from the schema
        if (!base.attributes.background) {
            try {
                base.attributes.background = {
                    value: lib_1.Backgrounds[(0, lodash_1.first)(type.schema.background)].name
                };
            }
            catch (e) {
                console.error(`Error for ${type.name}. ${(0, util_essentials_1.asMessage)(e)}`);
            }
        }
        return [
            ...list,
            {
                ...base,
                code: (0, lib_1.generateCodeByAttributes)(type, base.attributes)
            }
        ];
    }, []);
};
exports.readTestData = readTestData;
//# sourceMappingURL=utils.js.map