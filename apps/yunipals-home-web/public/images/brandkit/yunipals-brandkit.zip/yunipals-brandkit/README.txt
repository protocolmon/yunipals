YUNIPALS BRANDKIT

Website: https://www.yunipals.com
Brandkit: https://www.yunipals.com/brandkit

ASSETS
- Logo: 192 x 192, transparent PNG and WebP
- Collection banners: 1920 x 823, WebP
- Social artwork: 1200 x 630, JPG

WEBSITE COLORS
Lavender #C7C9F9
Sky      #B3E7F5
Mint     #CDF6CF
Grape    #7E22CE
Ink      #0D1526
White    #FFFFFF

TYPOGRAPHY
Headlines: Archivo Black, uppercase
Body and interface: Inter
Font files are not included.

DESIGN GUIDANCE
Write the name as Yunipals (one word, capital Y).
Keep the logo's proportions and colors, with breathing room around the mark.
Scale artwork evenly and keep the characters visible when placing banners.
Keep the tone playful, welcoming, and clear.
